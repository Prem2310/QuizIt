/** Shared API + domain types for QuizIt. */

export interface User {
  id?: string | number | undefined;
  name: string;
  email: string;
  username: string;
  college?: string | null;
  rating?: number | null;
  points?: number | null;
  correct?: number | null;
  incorrect?: number | null;
  rank?: number | null;
  avatar_url?: string | null;
}

export interface SignupPayload {
  name: string;
  email: string;
  password: string;
  username: string;
}

export interface UpdateProfilePayload {
  name?: string;
  email?: string;
  username?: string;
  college_name?: string | null;
  profile_picture_url?: string | null;
}

export interface LoginPayload {
  email: string;
  password: string;
}

/** Real question shape returned by the backend question table. */
export interface McqApiItem {
  id?: string | number | undefined;
  subtopic_id?: number | string;
  text?: string;
  text_html?: string | null;
  options?: string | unknown[] | null;
  options_html?: string | unknown[] | null;
  answer?: string | null;
  answer_letter?: string | null;
  explanation?: string | null;
  explanation_html?: string | null;
  difficulty?: string | null;
  page?: number | null;
  source?: string | null;
  source_url?: string | null;
  question_hash?: string | null;
  is_active?: boolean;
  created_at?: string | null;
  updated_at?: string | null;

  /** Legacy compatibility for older MCQ payloads. */
  question_text?: string;
  a?: string;
  b?: string;
  c?: string;
  d?: string;
  correct_option?: string;
  topic_id?: string | number;
  difficulty_level?: string | number;
}

export type OptionKey = "a" | "b" | "c" | "d";

/** Sanitised question used by gameplay UI. Correct answer is not part of it. */
export interface Question {
  id: string;
  text: string;
  textHtml?: string; // HTML version with embedded images
  options: Record<OptionKey, string>;
  optionsHtml?: Record<OptionKey, string>; // HTML versions with embedded images
  difficulty?: string;
  explanation?: string;
  explanationHtml?: string; // HTML version with embedded images
}

/** Answer key kept separate from the rendered question. */
export interface AnswerKeyEntry {
  id: string;
  correctOption: OptionKey | null;
  explanation?: string;
}

export interface QuestionSet {
  questions: Question[];
  answerKey: Record<string, AnswerKeyEntry>;
}

export type QuizMode = "random" | "ai" | "custom";

export interface CreateQuizPayload {
  topicName: string;
  numQuestions: number;
  usernames: string[];
  timePerQuestion: number;
  quizMode: QuizMode;
}

export interface QuizAttemptAnswer {
  questionId: string;
  selected: OptionKey | null;
  correct: boolean;
  timeMs: number;
}

export interface QuizAttemptResult {
  topic: string;
  total: number;
  correct: number;
  incorrect: number;
  skipped: number;
  accuracy: number;
  averageTimeMs: number;
  answers: QuizAttemptAnswer[];
  questions: Question[];
  answerKey: Record<string, AnswerKeyEntry>;
}

export type ConnectionState =
  | "IDLE"
  | "CONNECTING"
  | "OPEN"
  | "RECONNECTING"
  | "CLOSED"
  | "ERROR";

export type MatchmakingState =
  | "IDLE"
  | "SEARCHING"
  | "MATCH_FOUND"
  | "ERROR"
  | "CANCELLED"
  | "DISCONNECTED";

export interface MatchFoundPayload {
  roomId?: string;
  opponent?: { username: string; rating?: number };
  raw: unknown;
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  name: string;
  rating: number;
  points: number;
  accuracy: number;
  college?: string;
}

export interface ApiErrorShape {
  status: number;
  message: string;
}
