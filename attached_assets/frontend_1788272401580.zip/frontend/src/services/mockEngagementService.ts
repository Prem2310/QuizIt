/**
 * DEMO ONLY.
 * Streaks, XP, daily challenge metadata and achievements have no backend
 * endpoints yet.
 * TODO: Replace this demo provider with real backend endpoints when implemented.
 */
export interface DailyChallenge {
  title: string;
  questions: number;
  durationLabel: string;
  playersToday: number;
  topicBackendName: string;
}

export interface Achievement {
  id: string;
  emoji: string;
  title: string;
  description: string;
  unlocked: boolean;
}

export interface EngagementSummary {
  streakDays: number;
  xp: number;
  xpToNextLevel: number;
  level: number;
}

export const mockEngagementService = {
  isDemo: true,
  getSummary(): EngagementSummary {
    return { streakDays: 6, xp: 2480, xpToNextLevel: 3000, level: 7 };
  },
  getDailyChallenge(): DailyChallenge {
    return {
      title: "Speed Quant Sprint",
      questions: 10,
      durationLabel: "2 min",
      playersToday: 1842,
      topicBackendName: "Quantitative Aptitude",
    };
  },
  getAchievements(): Achievement[] {
    return [
      { id: "first-duel", emoji: "⚔️", title: "First Blood", description: "Win your first duel", unlocked: true },
      { id: "streak-7", emoji: "🔥", title: "Week Warrior", description: "7 day streak", unlocked: false },
      { id: "accuracy-90", emoji: "🎯", title: "Sharpshooter", description: "90% accuracy in a quiz", unlocked: true },
      { id: "speed-demon", emoji: "⚡", title: "Speed Demon", description: "Answer 10 questions under 5s each", unlocked: false },
    ];
  },
  getRecentActivity(): Array<{ id: string; label: string; detail: string; when: string }> {
    return [
      { id: "1", label: "Duel won", detail: "DSA · 2 questions", when: "2h ago" },
      { id: "2", label: "Practice completed", detail: "Percentages · 10 questions", when: "Yesterday" },
      { id: "3", label: "Daily challenge", detail: "Speed Quant Sprint", when: "2 days ago" },
    ];
  },
};
