import type { LeaderboardEntry } from "@/types";

/**
 * DEMO ONLY.
 * The backend exposes no leaderboard endpoint yet.
 * TODO: Replace demo leaderboard provider with backend endpoint when implemented.
 */
export type LeaderboardScope = "global" | "weekly" | "college" | "friends";

const NAMES: Array<[string, string, string]> = [
  ["Aarav Mehta", "aarav", "IIT Bombay"],
  ["Ishita Rao", "ishita", "NIT Trichy"],
  ["Kabir Shah", "kabir_s", "BITS Pilani"],
  ["Nisha Verma", "nishav", "VIT Vellore"],
  ["Rohan Das", "rohan.d", "IIIT Hyderabad"],
  ["Meera Nair", "meeran", "Anna University"],
  ["Dev Patel", "devp", "DTU"],
  ["Sara Khan", "sarak", "Jadavpur"],
  ["Arjun Iyer", "arjun_i", "PSG Tech"],
  ["Tanvi Joshi", "tanvij", "COEP"],
  ["Vikram Sen", "vikrams", "NSUT"],
  ["Priya Menon", "priyam", "MIT Manipal"],
];

function build(seed: number): LeaderboardEntry[] {
  return NAMES.map(([name, username, college], i) => ({
    rank: i + 1,
    name,
    username,
    college,
    rating: 2180 - i * 47 - seed * 13,
    points: 48200 - i * 1830 - seed * 400,
    accuracy: Math.max(58, 94 - i * 2 - seed),
  }));
}

export const mockLeaderboardService = {
  isDemo: true,
  async getLeaderboard(scope: LeaderboardScope): Promise<LeaderboardEntry[]> {
    await new Promise((r) => setTimeout(r, 260));
    const seed = { global: 0, weekly: 1, college: 2, friends: 3 }[scope];
    const rows = build(seed);
    return scope === "friends" ? rows.slice(0, 5).map((r, i) => ({ ...r, rank: i + 1 })) : rows;
  },
};
