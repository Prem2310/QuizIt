import { SocketManager } from "@/lib/websocket";
import { WS_PATHS, wsUrl } from "@/lib/config";
import type { ConnectionState, MatchFoundPayload, MatchmakingState } from "@/types";

export interface MatchmakingHandlers {
  onState: (state: MatchmakingState) => void;
  onConnection: (state: ConnectionState) => void;
  onMatchFound: (payload: MatchFoundPayload) => void;
  onError: (message: string) => void;
}

/**
 * Matchmaking over WS /duelroom/match-lobby (cookie authenticated).
 * NOTE: the current backend hardcodes DSA / 2 questions — no filters are sent.
 */
export function createMatchmakingService(handlers: MatchmakingHandlers) {
  const manager = new SocketManager({
    url: wsUrl(WS_PATHS.matchLobby),
    heartbeat: { message: { type: "ping" }, intervalMs: 20000 },
    onStateChange: (state) => {
      handlers.onConnection(state);
      if (state === "OPEN") handlers.onState("SEARCHING");
      if (state === "ERROR") handlers.onState("ERROR");
      if (state === "CLOSED") handlers.onState("DISCONNECTED");
    },
    onError: handlers.onError,
    onMessage: (data) => {
      const payload = data && typeof data === "object" ? (data as Record<string, unknown>) : {};
      const type = String(payload["type"] ?? payload["event"] ?? payload["status"] ?? "").toLowerCase();
      const looksMatched =
        type.includes("match") || Boolean(payload["room_id"] ?? payload["roomId"] ?? payload["quiz_id"]);

      if (looksMatched) {
        const opponentRaw = payload["opponent"];
        const found: MatchFoundPayload = { raw: data };
        const roomId = payload["room_id"] ?? payload["roomId"] ?? payload["quiz_id"];
        if (roomId !== undefined && roomId !== null) found.roomId = String(roomId);
        if (opponentRaw && typeof opponentRaw === "object") {
          const o = opponentRaw as Record<string, unknown>;
          const opp: { username: string; rating?: number } = {
            username: String(o["username"] ?? o["name"] ?? "Opponent"),
          };
          if (typeof o["rating"] === "number") opp.rating = o["rating"];
          found.opponent = opp;
        } else if (typeof payload["opponent"] === "string") {
          found.opponent = { username: payload["opponent"] as string };
        }
        handlers.onState("MATCH_FOUND");
        handlers.onMatchFound(found);
      }
    },
  });

  return {
    start() {
      handlers.onState("SEARCHING");
      manager.connect();
    },
    cancel() {
      manager.send({ type: "cancel" });
      manager.disconnect();
      handlers.onState("CANCELLED");
    },
    dispose() {
      manager.disconnect();
    },
  };
}
