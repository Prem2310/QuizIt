import { apiRequest } from "@/lib/api";
import type { CreateQuizPayload } from "@/types";

export const quizService = {
  /**
   * POST /quiz/create-quiz
   * Only quizMode "random" is fully supported by the current backend;
   * "ai" and "custom" are surfaced in the UI as Coming Soon.
   */
  async createQuiz(payload: CreateQuizPayload): Promise<unknown> {
    return apiRequest<unknown>("/quiz/create-quiz", { method: "POST", body: payload });
  },
};
