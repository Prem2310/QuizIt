import { BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/api";
import { TOPICS, type TopicMeta } from "@/constants/topics";

function mapBackendTopic(raw: Partial<{ id: number; name: string; slug: string; description: string | null; is_active: boolean }>): TopicMeta | null {
  const name = raw.name?.trim();
  if (!name) return null;

  const fallback = TOPICS.find((t) => t.backendName.toLowerCase() === name.toLowerCase() || t.slug === raw.slug);
  const label = fallback?.label ?? name;
  const backendName = fallback?.backendName ?? name;
  const slug = raw.slug?.trim() || fallback?.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-");

  const fallbackIcon = fallback?.icon ?? TOPICS[0]?.icon ?? BookOpen;

  return {
    slug,
    backendName,
    label,
    category: fallback?.category ?? "Quantitative",
    difficulty: fallback?.difficulty ?? "Medium",
    icon: fallbackIcon,
    blurb: raw.description?.trim() || fallback?.blurb || "Practice questions on this topic.",
  };
}

export const topicService = {
  async list(): Promise<TopicMeta[]> {
    try {
      const data = await apiRequest<Array<Partial<{ id: number; name: string; slug: string; description: string | null; is_active: boolean }>>>('/topics/');
      const parsed = data
        .filter((item) => item && typeof item.name === 'string' && item.is_active !== false)
        .map((item) => mapBackendTopic(item))
        .filter(Boolean) as TopicMeta[];

      if (parsed.length > 0) return parsed;
    } catch {
      // Fall back to static metadata when the backend is not ready.
    }

    return TOPICS;
  },

  /** POST /topics/ — creates a topic on the backend. */
  async create(topicName: string): Promise<unknown> {
    return apiRequest<unknown>("/topics/", { method: "POST", body: { name: topicName } });
  },
};
