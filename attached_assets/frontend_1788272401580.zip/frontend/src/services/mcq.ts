import { apiRequest } from "@/lib/api";
import type { AnswerKeyEntry, McqApiItem, OptionKey, Question, QuestionSet } from "@/types";

const OPTION_KEYS: OptionKey[] = ["a", "b", "c", "d"];

function parseOptions(value: unknown): Record<OptionKey, string> {
  const fallback: Record<OptionKey, string> = { a: "", b: "", c: "", d: "" };

  const list: string[] = [];
  if (Array.isArray(value)) {
    value.forEach((entry) => {
      if (typeof entry === "string") list.push(entry);
    });
  } else if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as unknown;
      if (Array.isArray(parsed)) {
        parsed.forEach((entry) => {
          if (typeof entry === "string") list.push(entry);
        });
      }
    } catch {
      const trimmed = value.trim();
      if (trimmed) list.push(trimmed);
    }
  }

  OPTION_KEYS.forEach((key, idx) => {
    fallback[key] = list[idx] ?? "";
  });

  return fallback;
}

function toOptionKey(value: unknown): OptionKey | null {
  if (typeof value !== "string") return null;
  const v = value.trim().toLowerCase();
  if ((OPTION_KEYS as string[]).includes(v)) return v as OptionKey;
  if (["1", "2", "3", "4"].includes(v)) return OPTION_KEYS[Number(v) - 1] ?? null;
  const upper = value.trim().toUpperCase();
  if (["A", "B", "C", "D", "E"].includes(upper)) return OPTION_KEYS["ABCDE".indexOf(upper)] ?? null;
  return null;
}

function parseOptionsHtml(value: unknown): Record<OptionKey, string> | undefined {
  if (!value) return undefined;
  const fallback: Record<OptionKey, string> = { a: "", b: "", c: "", d: "" };
  const list: string[] = [];

  if (Array.isArray(value)) {
    value.forEach((entry) => {
      if (typeof entry === "string") list.push(entry);
    });
  } else if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as unknown;
      if (Array.isArray(parsed)) {
        parsed.forEach((entry) => {
          if (typeof entry === "string") list.push(entry);
        });
      }
    } catch {
      const trimmed = value.trim();
      if (trimmed) list.push(trimmed);
    }
  }

  const hasContent = list.some((html) => html?.trim().length);
  if (!hasContent) return undefined;

  OPTION_KEYS.forEach((key, idx) => {
    fallback[key] = list[idx] ?? "";
  });

  return fallback;
}

function resolveAnswerKey(item: McqApiItem): OptionKey | null {
  const answerLetter = typeof item.answer_letter === "string" ? item.answer_letter.trim().toUpperCase() : null;
  if (answerLetter && answerLetter.length) {
    const idx = "ABCDE".indexOf(answerLetter);
    if (idx >= 0) return OPTION_KEYS[idx] ?? null;
  }

  const answerText = typeof item.answer === "string" ? item.answer.trim() : null;
  if (answerText) {
    const options = parseOptions(item.options ?? []);
    const matchIndex = OPTION_KEYS.findIndex((key) => options[key] === answerText);
    if (matchIndex >= 0) return OPTION_KEYS[matchIndex] ?? null;
  }

  const legacy = typeof item.correct_option === "string" ? item.correct_option.trim().toLowerCase() : null;
  if (legacy) return toOptionKey(legacy);

  return null;
}

/**
 * Splits the backend payload into a render-safe question list and a private
 * answer key. The answer key is never passed into gameplay components.
 */
export function toQuestionSet(items: McqApiItem[]): QuestionSet {
  const questions: Question[] = [];
  const answerKey: Record<string, AnswerKeyEntry> = {};

  items.forEach((item, index) => {
    const id = String(item.id ?? `q-${index}`);
    const text = item.text ?? item.question_text ?? "";
    const options = parseOptions(item.options ?? [item.a, item.b, item.c, item.d]);
    const optionsHtml = parseOptionsHtml(item.options_html);

    const question: Question = {
      id,
      text,
      options,
    };

    // Add HTML versions if available (e.g., for embedded images)
    const textHtml = typeof item.text_html === "string" ? item.text_html.trim() : undefined;
    if (textHtml) question.textHtml = textHtml;

    if (optionsHtml) question.optionsHtml = optionsHtml;

    const difficulty = item.difficulty ?? item.difficulty_level;
    if (difficulty !== undefined && difficulty !== null && String(difficulty).trim() !== "") {
      question.difficulty = String(difficulty);
    }

    const explanation = item.explanation ?? undefined;
    if (explanation && explanation.trim()) question.explanation = explanation;

    const explanationHtml = typeof item.explanation_html === "string" ? item.explanation_html.trim() : undefined;
    if (explanationHtml) question.explanationHtml = explanationHtml;

    questions.push(question);

    const entry: AnswerKeyEntry = { id, correctOption: resolveAnswerKey(item) };
    if (question.explanation || question.explanationHtml) {
      entry.explanation = question.explanation || undefined;
    }
    answerKey[id] = entry;
  });

  return { questions, answerKey };
}

export const mcqService = {
  /** GET /mcqs/get_mcqs/{count}/{topic_name} */
  async getQuestions(count: number, topicName: string): Promise<QuestionSet> {
    const data = await apiRequest<unknown>(
      `/mcqs/get_mcqs/${count}/${encodeURIComponent(topicName)}`,
    );
    const list = Array.isArray(data)
      ? (data as McqApiItem[])
      : ((data as { questions?: McqApiItem[]; mcqs?: McqApiItem[] })?.questions ?? (data as { mcqs?: McqApiItem[] })?.mcqs ?? []);
    return toQuestionSet(list);
  },
};
