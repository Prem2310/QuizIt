import { SocketManager } from "@/lib/websocket";
import { WS_PATHS, wsUrl } from "@/lib/config";
import type { AnswerKeyEntry, ConnectionState, McqApiItem, OptionKey, Question } from "@/types";
import { toQuestionSet } from "./mcq";

export interface DuelSnapshot {
  question: Question | null;
  /** Private: never rendered while the question is active. */
  answer: AnswerKeyEntry | null;
  index: number;
  total: number;
  myScore: number;
  opponentScore: number;
  opponentName: string | null;
  finished: boolean;
}

export interface DuelHandlers {
  onSnapshot: (patch: Partial<DuelSnapshot>) => void;
  onConnection: (state: ConnectionState) => void;
  onError: (message: string) => void;
  onMessage?: (raw: unknown) => void;
}

/**
 * Duel gameplay over WS /duelroom/join-room-test (cookie authenticated).
 * The backend resolves the active quiz from the HTTP-only access_token cookie,
 * so no ids or tokens are placed in the URL.
 * The legacy /ws/duelroom/{roomId} endpoint is intentionally NOT used.
 */
export function createDuelService(handlers: DuelHandlers) {
  const manager = new SocketManager({
    url: wsUrl(WS_PATHS.duelRoom),
    heartbeat: { message: { type: "ping" }, intervalMs: 20000 },
    onStateChange: handlers.onConnection,
    onError: handlers.onError,
    onMessage: (data) => {
      handlers.onMessage?.(data);
      if (!data || typeof data !== "object") return;
      const payload = data as Record<string, unknown>;

      const questionRaw = (payload["question"] ?? payload["mcq"]) as McqApiItem | undefined;
      if (questionRaw && typeof questionRaw === "object" && "question_text" in questionRaw) {
        const { questions, answerKey } = toQuestionSet([questionRaw]);
        const question = questions[0] ?? null;
        handlers.onSnapshot({
          question,
          answer: question ? (answerKey[question.id] ?? null) : null,
          ...(typeof payload["index"] === "number" ? { index: payload["index"] as number } : {}),
          ...(typeof payload["total"] === "number" ? { total: payload["total"] as number } : {}),
        });
      }

      if (typeof payload["my_score"] === "number" || typeof payload["score"] === "number") {
        handlers.onSnapshot({ myScore: Number(payload["my_score"] ?? payload["score"]) });
      }
      if (typeof payload["opponent_score"] === "number") {
        handlers.onSnapshot({ opponentScore: payload["opponent_score"] as number });
      }
      if (typeof payload["opponent"] === "string") {
        handlers.onSnapshot({ opponentName: payload["opponent"] as string });
      }
      const type = String(payload["type"] ?? payload["event"] ?? "").toLowerCase();
      if (type.includes("end") || type.includes("finish") || payload["finished"] === true) {
        handlers.onSnapshot({ finished: true });
      }
    },
  });

  return {
    connect: () => manager.connect(),
    submitAnswer(questionId: string, option: OptionKey) {
      return manager.send({ type: "answer", question_id: questionId, answer: option });
    },
    disconnect: () => manager.disconnect(),
  };
}
