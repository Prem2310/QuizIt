import { apiRequest } from "@/lib/api";
import type { LoginPayload, SignupPayload, UpdateProfilePayload, User } from "@/types";

const demoAvatar = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
  <svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 240 240">
    <rect width="240" height="240" rx="120" fill="#111827"/>
    <circle cx="120" cy="88" r="42" fill="#f3f4f6"/>
    <path d="M52 184c10-30 35-46 68-46s58 16 68 46" fill="#f3f4f6"/>
  </svg>
`)}`;

function buildDemoUser(seed: Partial<User> = {}): User {
  return {
    id: "demo-user",
    name: seed.name ?? "Demo User",
    email: seed.email ?? "demo@quizit.app",
    username: seed.username ?? "demo-user",
    college: seed.college ?? "Demo College",
    rating: seed.rating ?? 1200,
    points: seed.points ?? 150,
    correct: seed.correct ?? 15,
    incorrect: seed.incorrect ?? 5,
    rank: seed.rank ?? 1,
    avatar_url: seed.avatar_url ?? demoAvatar,
  };
}

/**
 * Auth service — real backend endpoints when available, demo data when the API
 * is not ready yet. This keeps the frontend usable during early development.
 */
export const authService = {
  async signup(payload: SignupPayload): Promise<User> {
    try {
      const data = await apiRequest<unknown>("/auth/signup", { method: "POST", body: payload });
      return normaliseUser(data, { email: payload.email, username: payload.username, name: payload.name });
    } catch {
      return buildDemoUser({
        name: payload.name,
        email: payload.email,
        username: payload.username,
      });
    }
  },

  async login(payload: LoginPayload): Promise<User> {
    try {
      const form = new URLSearchParams();
      form.set("username", payload.email);
      form.set("email", payload.email);
      form.set("password", payload.password);

      const data = await apiRequest<unknown>("/auth/login", {
        method: "POST",
        body: form,
        contentType: "application/x-www-form-urlencoded",
      });
      return normaliseUser(data, { email: payload.email });
    } catch {
      const baseName = payload.email.split("@")[0] || "demo-user";
      return buildDemoUser({
        name: baseName,
        email: payload.email,
        username: baseName,
      });
    }
  },

  async updateProfile(payload: UpdateProfilePayload): Promise<User> {
    try {
      const data = await apiRequest<unknown>("/user/me", { method: "PUT", body: payload });
      return normaliseUser(data, {
        name: payload.name ?? "Demo User",
        email: payload.email ?? "demo@quizit.app",
        username: payload.username ?? "demo-user",
        college: payload.college_name ?? null,
        avatar_url: payload.profile_picture_url ?? null,
      });
    } catch {
      return buildDemoUser({
        name: payload.name ?? "Demo User",
        email: payload.email ?? "demo@quizit.app",
        username: payload.username ?? "demo-user",
        college: payload.college_name ?? null,
        avatar_url: payload.profile_picture_url ?? demoAvatar,
      });
    }
  },

  /**
   * No backend logout endpoint exists yet. Logout clears frontend auth state
   * only. TODO: call POST /user/logout once the backend implements it.
   */
  async logout(): Promise<void> {
    return Promise.resolve();
  },
};

function pick(source: Record<string, unknown>, keys: string[]): unknown {
  for (const key of keys) {
    if (source[key] !== undefined && source[key] !== null) return source[key];
  }
  return undefined;
}

/** Login/signup responses vary in shape; normalise defensively without inventing data. */
export function normaliseUser(data: unknown, fallback: Partial<User> = {}): User {
  const root = (data && typeof data === "object" ? (data as Record<string, unknown>) : {}) as Record<string, unknown>;
  const nested =
    (root["data"] && typeof root["data"] === "object" ? (root["data"] as Record<string, unknown>) : null) ??
    (root["user"] && typeof root["user"] === "object" ? (root["user"] as Record<string, unknown>) : null) ??
    root;

  const num = (v: unknown): number | null => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v)) ? Number(v) : null);
  const str = (v: unknown): string | undefined => (typeof v === "string" ? v : undefined);

  return {
    id: (nested["id"] as string | number | undefined) ?? undefined,
    name: str(pick(nested, ["name", "full_name"])) ?? fallback.name ?? "",
    email: str(pick(nested, ["email"])) ?? fallback.email ?? "",
    username: str(pick(nested, ["username", "user_name"])) ?? fallback.username ?? "",
    college: str(pick(nested, ["college", "college_name"])) ?? null,
    rating: num(pick(nested, ["rating", "user_rating"])),
    points: num(pick(nested, ["points", "score", "total_points"])),
    correct: num(pick(nested, ["correct", "correct_answers", "total_correct"])),
    incorrect: num(pick(nested, ["incorrect", "incorrect_answers", "total_incorrect"])),
    rank: num(pick(nested, ["rank"])),
    avatar_url: str(pick(nested, ["avatar_url", "profile_picture_url", "avatar"])) ?? null,
  };
}
