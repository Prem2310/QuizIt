import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth } from "@/stores/auth";

/** Client-side guard: sends unauthenticated visitors to /login. */
export function useRequireAuth() {
  const { isReady, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isReady && !isAuthenticated) {
      void navigate({ to: "/login", replace: true });
    }
  }, [isReady, isAuthenticated, navigate]);

  return { isReady, isAuthenticated };
}
