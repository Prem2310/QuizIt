import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { authService } from "@/services/auth";
import type { LoginPayload, SignupPayload, UpdateProfilePayload, User } from "@/types";

const PROFILE_KEY = "quizit.profile";

interface AuthContextValue {
  user: User | null;
  isReady: boolean;
  isAuthenticated: boolean;
  login: (payload: LoginPayload) => Promise<User>;
  signup: (payload: SignupPayload) => Promise<User>;
  updateProfile: (payload: UpdateProfilePayload) => Promise<User>;
  updateUser: (updates: Partial<User>) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

/**
 * Auth state.
 * Only the non-sensitive user profile is cached (never a token — the session
 * lives in an HTTP-only `access_token` cookie owned by the backend).
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    try {
      const cached = window.localStorage.getItem(PROFILE_KEY);
      if (cached) setUser(JSON.parse(cached) as User);
    } catch {
      /* ignore corrupt cache */
    }
    setIsReady(true);
  }, []);

  const persist = useCallback((next: User | null) => {
    setUser(next);
    try {
      if (next) window.localStorage.setItem(PROFILE_KEY, JSON.stringify(next));
      else window.localStorage.removeItem(PROFILE_KEY);
    } catch {
      /* storage unavailable */
    }
  }, []);

  const login = useCallback(
    async (payload: LoginPayload) => {
      const next = await authService.login(payload);
      persist(next);
      return next;
    },
    [persist],
  );

  const signup = useCallback(
    async (payload: SignupPayload) => {
      const next = await authService.signup(payload);
      persist(next);
      return next;
    },
    [persist],
  );

  const updateProfile = useCallback(
    async (payload: UpdateProfilePayload) => {
      const baseUser = user ?? {
        name: "Demo User",
        email: "demo@quizit.app",
        username: "demo-user",
        college: null,
        avatar_url: null,
      };

      try {
        const next = await authService.updateProfile(payload);
        persist(next);
        return next;
      } catch {
        const fallback: User = {
          ...baseUser,
          name: payload.name ?? baseUser.name,
          email: payload.email ?? baseUser.email,
          username: payload.username ?? baseUser.username,
          college: payload.college_name ?? baseUser.college ?? null,
          avatar_url: payload.profile_picture_url ?? baseUser.avatar_url ?? null,
        };

        persist(fallback);
        return fallback;
      }
    },
    [persist, user],
  );

  const updateUser = useCallback(
    (updates: Partial<User>) => {
      if (!user) return;
      persist({ ...user, ...updates });
    },
    [persist, user],
  );

  const logout = useCallback(async () => {
    // No backend logout endpoint exists; clear local state only.
    await authService.logout();
    persist(null);
  }, [persist]);

  const value = useMemo<AuthContextValue>(
    () => ({ user, isReady, isAuthenticated: Boolean(user), login, signup, updateProfile, updateUser, logout }),
    [user, isReady, login, signup, updateProfile, updateUser, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
