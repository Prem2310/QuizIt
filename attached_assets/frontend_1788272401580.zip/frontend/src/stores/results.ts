import type { QuizAttemptResult } from "@/types";

/**
 * Short-lived result handoff between a quiz screen and its result screen.
 * Uses sessionStorage so a refresh on the result page still works.
 */
const KEY = "quizit.lastResult";
const DUEL_KEY = "quizit.lastDuelResult";

export interface DuelResultSummary {
  duelId: string;
  myScore: number;
  opponentScore: number;
  opponentName: string;
  total: number;
  ratingBefore: number;
  ratingAfter: number;
  xpGained: number;
}

function read<T>(key: string): T | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function write(key: string, value: unknown): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable */
  }
}

export const resultsStore = {
  saveQuiz: (result: QuizAttemptResult) => write(KEY, result),
  loadQuiz: () => read<QuizAttemptResult>(KEY),
  saveDuel: (result: DuelResultSummary) => write(DUEL_KEY, result),
  loadDuel: () => read<DuelResultSummary>(DUEL_KEY),
};
