import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/common/StateBlocks";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TOPIC_CATEGORIES, type TopicDifficulty, type TopicMeta } from "@/constants/topics";
import { topicService } from "@/services/topic";

export const Route = createFileRoute("/_shell/practice/")({
  head: () => ({
    meta: [
      { title: "Practice — QuizIt" },
      { name: "description", content: "Practise quantitative aptitude, reasoning, verbal ability and more, topic by topic." },
      { property: "og:title", content: "Practice — QuizIt" },
      { property: "og:description", content: "Pick a topic and drill aptitude questions at your own pace." },
    ],
  }),
  component: PracticePage,
});

const DIFFICULTIES: TopicDifficulty[] = ["Easy", "Medium", "Hard"];

function PracticePage() {
  const [topics, setTopics] = useState<TopicMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [difficulty, setDifficulty] = useState("all");

  useEffect(() => {
    void topicService.list().then((data) => {
      setTopics(data);
      setLoading(false);
    }).catch(() => {
      setTopics([]);
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(
    () =>
      topics.filter((t) => {
        const matchesQuery = t.label.toLowerCase().includes(query.trim().toLowerCase());
        const matchesCategory = category === "all" || t.category === category;
        const matchesDifficulty = difficulty === "all" || t.difficulty === difficulty;
        return matchesQuery && matchesCategory && matchesDifficulty;
      }),
    [topics, query, category, difficulty],
  );

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Train solo" title="Practice" description="Pick a topic, set your length and drill at your own pace." />

      <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto_auto]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search topics"
            aria-label="Search topics"
            className="h-11 pl-9"
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="h-11 w-full sm:w-44" aria-label="Filter by category">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {TOPIC_CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={difficulty} onValueChange={setDifficulty}>
          <SelectTrigger className="h-11 w-full sm:w-40" aria-label="Filter by difficulty">
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All levels</SelectItem>
            {DIFFICULTIES.map((d) => (
              <SelectItem key={d} value={d}>
                {d}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="surface-panel p-6 text-sm text-muted-foreground">Loading topics...</div>
      ) : filtered.length === 0 ? (
        <EmptyState title="No topics found" message="Try a different search term or clear the filters." />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((topic) => (
            <Link
              key={topic.slug}
              to="/practice/$topic"
              params={{ topic: topic.slug }}
              className="surface-panel group flex flex-col gap-3 p-5 transition-transform hover:-translate-y-0.5 hover:border-primary-muted"
            >
              <div className="flex items-start justify-between gap-3">
                <topic.icon className="h-5 w-5 shrink-0 text-primary" />
                <Badge variant="outline" className="shrink-0 border-border text-[10px] uppercase tracking-wider text-muted-foreground">
                  {topic.difficulty}
                </Badge>
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{topic.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{topic.blurb}</p>
              </div>
              <p className="label-micro">{topic.category}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
