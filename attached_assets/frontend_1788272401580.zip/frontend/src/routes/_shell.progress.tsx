import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { DemoBadge } from "@/components/common/StateBlocks";
import { AnimatedNumber } from "@/components/common/AnimatedNumber";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/stores/auth";
import { mockEngagementService } from "@/services/mockEngagementService";

export const Route = createFileRoute("/_shell/progress")({
  head: () => ({
    meta: [
      { title: "Progress — QuizIt" },
      { name: "description", content: "Track your QuizIt accuracy, rating, XP and recent activity." },
      { property: "og:title", content: "Progress — QuizIt" },
      { property: "og:description", content: "Track your QuizIt accuracy, rating, XP and recent activity." },
    ],
  }),
  component: ProgressPage,
});

function ProgressPage() {
  const { user } = useAuth();
  const engagement = mockEngagementService.getSummary();
  const activity = mockEngagementService.getRecentActivity();

  const answered = (user?.correct ?? 0) + (user?.incorrect ?? 0);
  const accuracy = answered > 0 ? Math.round(((user?.correct ?? 0) / answered) * 100) : null;

  const stats: Array<{ label: string; value: number | null; suffix?: string; note?: string }> = [
    { label: "Overall accuracy", value: accuracy, suffix: "%" },
    { label: "Current rating", value: user?.rating ?? null },
    { label: "Points", value: user?.points ?? null },
    { label: "Correct answers", value: user?.correct ?? null },
    { label: "Incorrect answers", value: user?.incorrect ?? null },
    { label: "Global rank", value: user?.rank ?? null },
  ];

  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Your form" title="Progress" description="Everything the backend currently reports about your play." />

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="surface-panel p-4">
            <p className="label-micro">{s.label}</p>
            <p className="numeric mt-2 text-2xl font-bold">
              {s.value == null ? (
                <span className="text-sm text-muted-foreground">Not tracked yet</span>
              ) : (
                <AnimatedNumber value={s.value} suffix={s.suffix ?? ""} />
              )}
            </p>
          </div>
        ))}
      </section>

      <section className="surface-panel p-5">
        <div className="flex items-center justify-between gap-3">
          <p className="label-micro">XP &amp; level</p>
          <DemoBadge />
        </div>
        <p className="numeric mt-2 text-2xl font-bold">Level {engagement.level}</p>
        <Progress value={(engagement.xp / engagement.xpToNextLevel) * 100} className="mt-3 h-1.5" />
        <p className="mt-2 text-xs text-muted-foreground">
          {engagement.xp} / {engagement.xpToNextLevel} XP to the next level
        </p>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="label-micro">Topic performance</h2>
          <DemoBadge />
        </div>
        <div className="surface-panel p-5 text-sm text-muted-foreground">
          Per-topic accuracy, weak areas and average response time need a backend stats endpoint.
          <br />
          TODO: Replace with real per-topic analytics when the backend exposes them.
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="label-micro">Recent activity</h2>
          <DemoBadge />
        </div>
        <div className="surface-panel divide-y divide-border">
          {activity.map((item) => (
            <div key={item.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{item.label}</p>
                <p className="truncate text-xs text-muted-foreground">{item.detail}</p>
              </div>
              <span className="shrink-0 text-xs text-muted-foreground">{item.when}</span>
            </div>
          ))}
        </div>
      </section>

      <Separator className="bg-border" />
    </div>
  );
}
