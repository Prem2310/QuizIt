import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { LoadingState } from "@/components/common/StateBlocks";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/_shell")({
  component: ShellLayout,
});

function ShellLayout() {
  const { isReady, isAuthenticated } = useRequireAuth();

  if (!isReady || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <LoadingState label="Loading QuizIt…" />
      </div>
    );
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
