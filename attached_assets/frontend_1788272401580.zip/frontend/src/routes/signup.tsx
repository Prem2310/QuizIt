import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { AuthLayout } from "@/components/auth/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/stores/auth";
import { ApiError } from "@/lib/api";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create account — QuizIt" },
      { name: "description", content: "Create your QuizIt account and start duelling on aptitude questions." },
      { property: "og:title", content: "Create account — QuizIt" },
      { property: "og:description", content: "Create your QuizIt account and start duelling on aptitude questions." },
    ],
  }),
  component: SignupPage,
});

const schema = z.object({
  name: z.string().min(2, "Enter your name"),
  username: z
    .string()
    .min(3, "At least 3 characters")
    .regex(/^[a-zA-Z0-9._-]+$/, "Letters, numbers, dot, dash and underscore only"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "At least 6 characters"),
});
type FormValues = z.infer<typeof schema>;

function SignupPage() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", username: "", email: "", password: "" },
  });

  const onSubmit = async (values: FormValues) => {
    setError(null);
    try {
      // Real backend: POST /user/signup
      await signup(values);
      toast.success("Account created. Sign in to start playing.");
      void navigate({ to: "/login", replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Signup failed. Please try again.");
    }
  };

  const fields: Array<{ id: keyof FormValues; label: string; type: string; placeholder: string; autoComplete: string }> = [
    { id: "name", label: "Full name", type: "text", placeholder: "Prem Sharma", autoComplete: "name" },
    { id: "username", label: "Username", type: "text", placeholder: "prem", autoComplete: "username" },
    { id: "email", label: "Email", type: "email", placeholder: "you@college.edu", autoComplete: "email" },
    { id: "password", label: "Password", type: "password", placeholder: "••••••••", autoComplete: "new-password" },
  ];

  return (
    <AuthLayout
      eyebrow="Join QuizIt"
      title="Create your player"
      subtitle="Track your rating, streaks and accuracy from day one."
      footer={
        <>
          Already playing?{" "}
          <Link to="/login" className="font-semibold text-primary hover:underline">
            Sign in
          </Link>
        </>
      }
    >
      <form className="space-y-4" onSubmit={form.handleSubmit(onSubmit)} noValidate>
        {fields.map((field) => (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>{field.label}</Label>
            <Input
              id={field.id}
              type={field.type}
              placeholder={field.placeholder}
              autoComplete={field.autoComplete}
              {...form.register(field.id)}
            />
            {form.formState.errors[field.id] ? (
              <p className="text-xs text-destructive">{form.formState.errors[field.id]?.message}</p>
            ) : null}
          </div>
        ))}
        {error ? (
          <p role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </p>
        ) : null}
        <Button type="submit" className="h-12 w-full text-sm font-semibold" disabled={form.formState.isSubmitting}>
          {form.formState.isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Create account
        </Button>
      </form>
    </AuthLayout>
  );
}
