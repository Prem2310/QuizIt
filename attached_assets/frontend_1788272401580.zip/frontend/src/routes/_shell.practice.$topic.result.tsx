import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/common/StateBlocks";
import { SafeHtml } from "@/components/common/SafeHtml";
import { AnimatedNumber } from "@/components/common/AnimatedNumber";
import { resultsStore } from "@/stores/results";
import type { OptionKey, QuizAttemptResult } from "@/types";

export const Route = createFileRoute("/_shell/practice/$topic/result")({
  head: () => ({
    meta: [
      { title: "Practice result — QuizIt" },
      { name: "description", content: "Review your practice score, accuracy and full question breakdown." },
      { property: "og:title", content: "Practice result — QuizIt" },
      { property: "og:description", content: "Review your practice score, accuracy and full question breakdown." },
    ],
  }),
  component: ResultPage,
});

const KEYS: OptionKey[] = ["a", "b", "c", "d"];

function ResultPage() {
  const { topic } = useParams({ from: "/_shell/practice/$topic/result" });
  const [result, setResult] = useState<QuizAttemptResult | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setResult(resultsStore.loadQuiz());
    setReady(true);
  }, []);

  if (!ready) return null;

  if (!result) {
    return (
      <EmptyState
        title="No result to show"
        message="Finish a practice quiz to see your breakdown here."
        action={
          <Button asChild size="sm">
            <Link to="/practice/$topic" params={{ topic }}>
              Start practice
            </Link>
          </Button>
        }
      />
    );
  }

  const stats = [
    { label: "Score", value: result.correct, suffix: `/${result.total}` },
    { label: "Accuracy", value: result.accuracy, suffix: "%" },
    { label: "Correct", value: result.correct, suffix: "" },
    { label: "Incorrect", value: result.incorrect, suffix: "" },
    { label: "Skipped", value: result.skipped, suffix: "" },
    { label: "Avg time", value: Math.round(result.averageTimeMs / 100) / 10, suffix: "s" },
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="surface-panel p-6 text-center">
        <p className="label-micro">Quiz completed</p>
        <p className="numeric mt-2 text-5xl font-bold text-primary">
          <AnimatedNumber value={result.correct} />
          <span className="text-2xl text-muted-foreground">/{result.total}</span>
        </p>
        <p className="mt-2 text-sm text-muted-foreground">{result.topic}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button asChild className="h-11 px-6 font-semibold">
            <Link to="/practice/$topic" params={{ topic }}>
              Play again
            </Link>
          </Button>
          <Button asChild variant="outline" className="h-11 px-6">
            <Link to="/practice">All topics</Link>
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i }}
            className="surface-panel p-4"
          >
            <p className="label-micro">{s.label}</p>
            <p className="numeric mt-1 text-xl font-bold">
              <AnimatedNumber value={s.value} decimals={s.label === "Avg time" ? 1 : 0} suffix={s.suffix} />
            </p>
          </motion.div>
        ))}
      </div>

      <section className="space-y-3">
        <h2 className="label-micro">Question breakdown</h2>
        {result.questions.map((question, i) => {
          const answer = result.answers.find((a) => a.questionId === question.id);
          const key = result.answerKey[question.id];
          const correctOption = key?.correctOption ?? null;
          return (
            <div key={question.id} className="surface-panel p-4">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                {question.textHtml ? (
                  <SafeHtml html={question.textHtml} className="min-w-0 text-sm font-medium text-foreground [&_img]:max-w-full [&_img]:h-auto" />
                ) : (
                  <p className="min-w-0 text-sm font-medium text-foreground">
                    <span className="numeric mr-2 text-muted-foreground">{i + 1}.</span>
                    {question.text}
                  </p>
                )}
                <Badge
                  variant="outline"
                  className={
                    answer?.correct
                      ? "shrink-0 border-primary text-primary"
                      : answer?.selected == null
                        ? "shrink-0 border-border text-muted-foreground"
                        : "shrink-0 border-destructive text-destructive"
                  }
                >
                  {answer?.correct ? "Correct" : answer?.selected == null ? "Skipped" : "Wrong"}
                </Badge>
              </div>
              <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
                {KEYS.map((k) => {
                  const isCorrect = correctOption === k;
                  const isSelected = answer?.selected === k;
                  const htmlContent = question.optionsHtml?.[k];
                  return (
                    <div
                      key={k}
                      className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs ${
                        isCorrect
                          ? "border-primary/60 bg-primary/10 text-foreground"
                          : isSelected
                            ? "border-destructive/60 bg-destructive/10 text-foreground"
                            : "border-border text-muted-foreground"
                      }`}
                    >
                      <span className="numeric font-bold uppercase">{k}</span>
                      {htmlContent ? (
                        <SafeHtml html={htmlContent} className="min-w-0 flex-1 break-words [&_img]:max-w-full [&_img]:h-auto" />
                      ) : (
                        <span className="min-w-0 flex-1 break-words">{question.options[k]}</span>
                      )}
                      {isCorrect ? <Check className="h-3.5 w-3.5 shrink-0 text-primary" /> : null}
                      {isSelected && !isCorrect ? <X className="h-3.5 w-3.5 shrink-0 text-destructive" /> : null}
                    </div>
                  );
                })}
              </div>
              {key?.explanation || question.explanationHtml ? (
                <div className="mt-3 rounded-lg border border-border bg-surface p-3 text-xs text-muted-foreground">
                  {question.explanationHtml ? (
                    <SafeHtml html={question.explanationHtml} className="[&_img]:max-w-full [&_img]:h-auto" />
                  ) : (
                    <p>{key?.explanation}</p>
                  )}
                </div>
              ) : null}
            </div>
          );
        })}
      </section>
    </div>
  );
}
