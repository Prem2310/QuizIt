import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowRight, Flame, Swords, Target, Timer, TrendingUp, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DemoBadge } from "@/components/common/StateBlocks";
import { AnimatedNumber } from "@/components/common/AnimatedNumber";
import { mockEngagementService } from "@/services/mockEngagementService";
import { TOPICS } from "@/constants/topics";
import { useAuth } from "@/stores/auth";

export const Route = createFileRoute("/_shell/arena")({
  head: () => ({
    meta: [
      { title: "Arena — QuizIt" },
      { name: "description", content: "Your QuizIt arena: quick duels, daily challenges and practice sets." },
      { property: "og:title", content: "Arena — QuizIt" },
      { property: "og:description", content: "Quick duels, daily challenges and practice sets in one arena." },
    ],
  }),
  component: ArenaPage,
});

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

const PRACTICE_SHORTCUTS = ["quantitative-aptitude", "logical-reasoning", "verbal-ability"];

function ArenaPage() {
  const { user } = useAuth();
  const engagement = mockEngagementService.getSummary();
  const daily = mockEngagementService.getDailyChallenge();
  const firstName = (user?.name || user?.username || "player").split(" ")[0];
  const shortcuts = PRACTICE_SHORTCUTS.map((slug) => TOPICS.find((t) => t.slug === slug)!).filter(Boolean);

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-8">
      <div className="hidden items-center justify-between gap-4 lg:flex">
        <div>
          <p className="label-micro">{greeting()}</p>
          <h1 className="mt-1 text-2xl font-bold">{firstName}</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-sm font-semibold text-warning">
            <Flame className="h-4 w-4" /> {engagement.streakDays} day streak
          </span>
          <span className="flex items-center gap-1.5 text-sm font-semibold text-primary">
            <Zap className="h-4 w-4" /> {engagement.xp} XP
          </span>
          <DemoBadge />
        </div>
      </div>

      {/* Hero CTA */}
      <section className="surface-panel relative overflow-hidden p-6 sm:p-8">
        <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-primary/10 blur-3xl" />
        <p className="label-micro">Ready for a challenge?</p>
        <h2 className="mt-2 max-w-lg text-2xl font-bold leading-tight sm:text-4xl">
          Two minutes. One opponent. <span className="text-primary">Prove it.</span>
        </h2>
        <p className="mt-3 max-w-md text-sm text-muted-foreground">
          Get matched instantly and race an opponent question by question.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild size="lg" className="h-12 px-6 text-sm font-bold tracking-wide">
            <Link to="/matchmaking">
              <Swords className="mr-2 h-4 w-4" /> QUICK DUEL
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-12 px-6 text-sm font-semibold">
            <Link to="/practice">Practice instead</Link>
          </Button>
        </div>
      </section>

      {/* Daily challenge */}
      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h3 className="label-micro">Today's challenge</h3>
          <DemoBadge />
        </div>
        <div className="surface-panel grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 p-5 sm:flex sm:justify-between">
          <div className="min-w-0">
            <p className="truncate text-base font-semibold">{daily.title}</p>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Target className="h-3.5 w-3.5" /> {daily.questions} questions
              </span>
              <span className="flex items-center gap-1">
                <Timer className="h-3.5 w-3.5" /> {daily.durationLabel}
              </span>
              <span className="flex items-center gap-1">
                <Users className="h-3.5 w-3.5" /> {daily.playersToday.toLocaleString()} playing
              </span>
            </div>
          </div>
          <Button asChild className="shrink-0">
            <Link to="/challenges">Play</Link>
          </Button>
        </div>
      </section>

      {/* Duel modes */}
      <section className="grid gap-4 sm:grid-cols-2">
        <ModeCard
          to="/matchmaking"
          icon={<Swords className="h-5 w-5 text-primary" />}
          title="Quick Match"
          description="Ranked duel against a live opponent."
          note="DSA · 2 questions (backend fixed)"
        />
        <ModeCard
          to="/duels"
          icon={<Users className="h-5 w-5 text-primary" />}
          title="Challenge Friend"
          description="Create a private quiz and invite by username."
        />
      </section>

      {/* Practice shortcuts */}
      <section>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="label-micro">Practice</h3>
          <Link to="/practice" className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
            All topics <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          {shortcuts.map((topic) => (
            <Link
              key={topic.slug}
              to="/practice/$topic"
              params={{ topic: topic.slug }}
              className="surface-panel group flex items-center gap-3 p-4 transition-transform hover:-translate-y-0.5 hover:border-primary-muted"
            >
              <topic.icon className="h-5 w-5 shrink-0 text-primary" />
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{topic.label}</p>
                <p className="truncate text-xs text-muted-foreground">{topic.blurb}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Progress */}
      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h3 className="label-micro">Your progress</h3>
          <Link to="/progress" className="text-xs font-semibold text-primary hover:underline">
            Details
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <StatTile label="Rating" value={user?.rating ?? null} icon={<TrendingUp className="h-4 w-4" />} />
          <StatTile
            label="Accuracy"
            value={
              user && user.correct != null && user.incorrect != null && user.correct + user.incorrect > 0
                ? Math.round((user.correct / (user.correct + user.incorrect)) * 100)
                : null
            }
            suffix="%"
            icon={<Target className="h-4 w-4" />}
          />
          <StatTile label="Points" value={user?.points ?? null} icon={<Zap className="h-4 w-4" />} />
        </div>
        <div className="surface-panel mt-3 p-4">
          <div className="flex items-center justify-between text-xs">
            <span className="label-micro">Level {engagement.level}</span>
            <span className="text-muted-foreground">
              {engagement.xp} / {engagement.xpToNextLevel} XP
            </span>
          </div>
          <Progress value={(engagement.xp / engagement.xpToNextLevel) * 100} className="mt-2 h-1.5" />
        </div>
      </section>
    </motion.div>
  );
}

function ModeCard({
  to,
  icon,
  title,
  description,
  note,
}: {
  to: "/matchmaking" | "/duels";
  icon: React.ReactNode;
  title: string;
  description: string;
  note?: string;
}) {
  return (
    <Link to={to} className="surface-panel group p-5 transition-transform hover:-translate-y-0.5 hover:border-primary-muted">
      <div className="flex items-center gap-3">
        {icon}
        <p className="text-base font-semibold">{title}</p>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{description}</p>
      {note ? <p className="mt-3 label-micro">{note}</p> : null}
    </Link>
  );
}

function StatTile({
  label,
  value,
  suffix = "",
  icon,
}: {
  label: string;
  value: number | null;
  suffix?: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="surface-panel p-4">
      <div className="flex items-center gap-2 text-muted-foreground">
        {icon}
        <span className="label-micro">{label}</span>
      </div>
      <p className="numeric mt-2 text-2xl font-bold">
        {value == null ? <span className="text-base text-muted-foreground">—</span> : <AnimatedNumber value={value} suffix={suffix} />}
      </p>
    </div>
  );
}
