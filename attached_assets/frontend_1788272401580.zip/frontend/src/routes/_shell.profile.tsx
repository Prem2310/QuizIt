import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { initialsOf } from "@/components/layout/AppShell";
import { useAuth } from "@/stores/auth";
import { mockEngagementService } from "@/services/mockEngagementService";

export const Route = createFileRoute("/_shell/profile")({
  head: () => ({
    meta: [
      { title: "Profile — QuizIt" },
      { name: "description", content: "Your QuizIt player card: rating, points, accuracy and achievements." },
      { property: "og:title", content: "Profile — QuizIt" },
      { property: "og:description", content: "Your QuizIt player card: rating, points, accuracy and achievements." },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const achievements = mockEngagementService.getAchievements();
  const displayName = user?.name || user?.username || "Player";
  const avatarUrl = user?.avatar_url || undefined;

  const totalAnswered = (user?.correct ?? 0) + (user?.incorrect ?? 0);
  const accuracy = totalAnswered > 0 ? Math.round(((user?.correct ?? 0) / totalAnswered) * 100) : 0;

  const stats: Array<{ label: string; value: string }> = [
    { label: "Rating", value: user?.rating != null ? String(user.rating) : "—" },
    { label: "Points", value: user?.points != null ? String(user.points) : "—" },
    { label: "Correct", value: user?.correct != null ? String(user.correct) : "—" },
    { label: "Incorrect", value: user?.incorrect != null ? String(user.incorrect) : "—" },
    { label: "Accuracy", value: `${accuracy}%` },
  ];

  const handleLogout = async () => {
    // No backend logout endpoint yet — clear frontend state and return to /login.
    await logout();
    void navigate({ to: "/login", replace: true });
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Player card"
        title="Profile"
        actions={
          <Button variant="outline" className="h-10" onClick={() => void handleLogout()}>
            <LogOut className="mr-2 h-4 w-4" /> Log out
          </Button>
        }
      />

      <section className="surface-panel relative overflow-hidden p-6">
        <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-16 h-48 w-48 rounded-full bg-primary/10 blur-3xl" />
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
          <Avatar className="h-16 w-16 shrink-0 border border-border">
            {avatarUrl ? <AvatarImage src={avatarUrl} alt={displayName} /> : null}
            <AvatarFallback className="bg-surface text-lg font-bold text-primary">{initialsOf(displayName)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <h2 className="truncate text-xl font-bold">{displayName}</h2>
            <p className="truncate text-sm text-muted-foreground">@{user?.username || "unknown"}</p>
            <p className="mt-1 truncate text-xs text-muted-foreground">{user?.email || "No email set"}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              <Badge variant="outline" className="border-border text-xs text-muted-foreground">
                {user?.college || "College not set"}
              </Badge>
              <Badge className="text-xs">{user?.rating != null ? `${user.rating} rating` : "Unrated"}</Badge>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {stats.map((s) => (
            <div key={s.label} className="rounded-lg border border-border bg-surface p-3">
              <p className="label-micro">{s.label}</p>
              <p className="numeric mt-1 text-lg font-bold">{s.value}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="label-micro">Achievements</h2>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {achievements.map((a) => (
            <div
              key={a.id}
              className={`surface-panel flex items-center gap-3 p-4 ${a.unlocked ? "" : "opacity-55"}`}
            >
              <span className="text-xl" aria-hidden="true">
                {a.emoji}
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{a.title}</p>
                <p className="truncate text-xs text-muted-foreground">{a.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
