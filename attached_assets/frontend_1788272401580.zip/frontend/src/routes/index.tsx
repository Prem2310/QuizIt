import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Logo } from "@/components/brand/Logo";
import { useAuth } from "@/stores/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "QuizIt — Competitive Aptitude Arena" },
      {
        name: "description",
        content:
          "QuizIt is a competitive aptitude arena: duel other players, practise quant, reasoning and verbal, and climb the rating ladder.",
      },
      { property: "og:title", content: "QuizIt — Competitive Aptitude Arena" },
      {
        property: "og:description",
        content: "Duel, practise and climb the aptitude leaderboard. One more game.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { isReady, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isReady) return;
    void navigate({ to: isAuthenticated ? "/arena" : "/login", replace: true });
  }, [isReady, isAuthenticated, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <Logo />
    </div>
  );
}
