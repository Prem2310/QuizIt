import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, SkipForward } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ErrorState, LoadingState, EmptyState } from "@/components/common/StateBlocks";
import { QuestionPanel } from "@/components/quiz/QuestionPanel";
import { QuizTimer } from "@/components/quiz/QuizTimer";
import { PageHeader } from "@/components/common/PageHeader";
import { getTopicBySlug } from "@/constants/topics";
import { mcqService } from "@/services/mcq";
import { resultsStore } from "@/stores/results";
import { useCountdownTimer } from "@/hooks/useCountdownTimer";
import type { OptionKey, QuizAttemptAnswer, QuizAttemptResult } from "@/types";

export const Route = createFileRoute("/_shell/practice/$topic/")({
  head: () => ({
    meta: [
      { title: "Practice quiz — QuizIt" },
      { name: "description", content: "Run a timed practice set on your chosen aptitude topic." },
      { property: "og:title", content: "Practice quiz — QuizIt" },
      { property: "og:description", content: "Run a timed practice set on your chosen aptitude topic." },
    ],
  }),
  component: PracticeQuizPage,
});

const COUNTS = [5, 10, 15, 20];
const SECONDS_PER_QUESTION = 45;

function PracticeQuizPage() {
  const { topic: slug } = useParams({ from: "/_shell/practice/$topic/" });
  const topic = getTopicBySlug(slug);
  const [count, setCount] = useState(10);
  const [started, setStarted] = useState(false);

  if (!topic) {
    return (
      <EmptyState
        title="Unknown topic"
        message="That topic isn't available."
        action={
          <Button asChild variant="outline" size="sm">
            <Link to="/practice">Back to practice</Link>
          </Button>
        }
      />
    );
  }

  if (!started) {
    return (
      <div className="space-y-6">
        <Link to="/practice" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Practice
        </Link>
        <PageHeader eyebrow={topic.category} title={topic.label} description={topic.blurb} />
        <div className="surface-panel space-y-6 p-6">
          <div>
            <p className="label-micro">Questions</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {COUNTS.map((c) => (
                <Button key={c} variant={c === count ? "default" : "outline"} onClick={() => setCount(c)} className="h-11 w-16">
                  {c}
                </Button>
              ))}
            </div>
          </div>
          <div>
            <p className="label-micro">Difficulty</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Fixed to <span className="text-foreground">{topic.difficulty}</span> — the backend does not accept a difficulty
              filter yet.
            </p>
          </div>
          <div>
            <p className="label-micro">Timer</p>
            <p className="mt-2 text-sm text-muted-foreground">{SECONDS_PER_QUESTION}s per question</p>
          </div>
          <Button size="lg" className="h-12 w-full text-sm font-bold tracking-wide" onClick={() => setStarted(true)}>
            START PRACTICE
          </Button>
        </div>
      </div>
    );
  }

  return <QuizRunner topicSlug={slug} topicName={topic.backendName} count={count} />;
}

function QuizRunner({ topicSlug, topicName, count }: { topicSlug: string; topicName: string; count: number }) {
  const navigate = useNavigate();
  const { data, isPending, isError, error, refetch } = useQuery({
    queryKey: ["mcqs", topicName, count],
    queryFn: () => mcqService.getQuestions(count, topicName),
    staleTime: 0,
    retry: false,
  });

  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<OptionKey | null>(null);
  const answers = useRef<QuizAttemptAnswer[]>([]);
  const questionStart = useRef<number>(Date.now());

  const questions = useMemo(() => data?.questions ?? [], [data]);
  const current = questions[index];

  const finish = useCallback(
    (collected: QuizAttemptAnswer[]) => {
      if (!data) return;
      const correct = collected.filter((a) => a.correct).length;
      const skipped = collected.filter((a) => a.selected === null).length;
      const incorrect = collected.length - correct - skipped;
      const result: QuizAttemptResult = {
        topic: topicName,
        total: collected.length,
        correct,
        incorrect,
        skipped,
        accuracy: collected.length ? Math.round((correct / collected.length) * 100) : 0,
        averageTimeMs: collected.length ? Math.round(collected.reduce((s, a) => s + a.timeMs, 0) / collected.length) : 0,
        answers: collected,
        questions: data.questions,
        answerKey: data.answerKey,
      };
      resultsStore.saveQuiz(result);
      void navigate({ to: "/practice/$topic/result", params: { topic: topicSlug }, replace: true });
    },
    [data, navigate, topicName, topicSlug],
  );

  const advance = useCallback(
    (choice: OptionKey | null) => {
      if (!data || !current) return;
      // Scoring happens locally only for practice feedback; the backend is the
      // scoring authority for competitive modes.
      const key = data.answerKey[current.id];
      const record: QuizAttemptAnswer = {
        questionId: current.id,
        selected: choice,
        correct: choice != null && key?.correctOption === choice,
        timeMs: Date.now() - questionStart.current,
      };
      const collected = [...answers.current, record];
      answers.current = collected;
      setSelected(null);
      questionStart.current = Date.now();
      if (index + 1 >= questions.length) finish(collected);
      else setIndex((i) => i + 1);
    },
    [current, data, finish, index, questions.length],
  );

  const handleExpire = useCallback(() => advance(null), [advance]);
  const secondsLeft = useCountdownTimer(SECONDS_PER_QUESTION, current?.id ?? "none", handleExpire, Boolean(current));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (["a", "b", "c", "d"].includes(key)) setSelected(key as OptionKey);
      if (e.key === "Enter" && selected) advance(selected);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected, advance]);

  if (isPending) return <LoadingState label="Loading questions…" />;
  if (isError) {
    return <ErrorState title="Quiz could not be loaded." message={(error as Error).message} onRetry={() => void refetch()} />;
  }
  if (!questions.length) {
    return (
      <EmptyState
        title="No questions yet"
        message={`The backend returned no questions for "${topicName}".`}
        action={
          <Button asChild variant="outline" size="sm">
            <Link to="/practice">Choose another topic</Link>
          </Button>
        }
      />
    );
  }
  if (!current) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <p className="label-micro truncate">{topicName}</p>
          <p className="numeric mt-0.5 text-sm font-semibold">
            Question {index + 1}/{questions.length}
          </p>
        </div>
        <QuizTimer secondsLeft={secondsLeft} total={SECONDS_PER_QUESTION} />
      </div>
      <Progress value={((index + 1) / questions.length) * 100} className="h-1.5" />

      {/* Correct answers are intentionally not passed here. */}
      <QuestionPanel question={current} selected={selected} onSelect={setSelected} />

      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" className="h-12" onClick={() => advance(null)}>
          <SkipForward className="mr-2 h-4 w-4" /> Skip
        </Button>
        <Button className="h-12 font-semibold" disabled={!selected} onClick={() => selected && advance(selected)}>
          {index + 1 === questions.length ? "Submit" : "Next"}
        </Button>
      </div>
      <p className="hidden text-center text-xs text-muted-foreground sm:block">
        Press A / B / C / D to select, Enter to continue
      </p>
    </div>
  );
}
