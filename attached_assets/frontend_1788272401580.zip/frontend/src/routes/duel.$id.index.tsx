import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ConnectionIndicator, LoadingState } from "@/components/common/StateBlocks";
import { QuestionPanel } from "@/components/quiz/QuestionPanel";
import { Countdown } from "@/components/quiz/Countdown";
import { useRequireAuth } from "@/hooks/useRequireAuth";
import { useAuth } from "@/stores/auth";
import { createDuelService, type DuelSnapshot } from "@/services/duel";
import { resultsStore } from "@/stores/results";
import { initialsOf } from "@/components/layout/AppShell";
import type { ConnectionState, OptionKey } from "@/types";

export const Route = createFileRoute("/duel/$id/")({
  head: () => ({
    meta: [
      { title: "Duel room — QuizIt" },
      { name: "description", content: "Live QuizIt duel: answer faster and more accurately than your opponent." },
      { property: "og:title", content: "Duel room — QuizIt" },
      { property: "og:description", content: "Live QuizIt duel: answer faster and more accurately than your opponent." },
    ],
  }),
  component: DuelRoomPage,
});

const INITIAL: DuelSnapshot = {
  question: null,
  answer: null,
  index: 0,
  total: 0,
  myScore: 0,
  opponentScore: 0,
  opponentName: null,
  finished: false,
};

function DuelRoomPage() {
  const { id } = useParams({ from: "/duel/$id/" });
  const { isReady, isAuthenticated } = useRequireAuth();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [snapshot, setSnapshot] = useState<DuelSnapshot>(INITIAL);
  const [connection, setConnection] = useState<ConnectionState>("IDLE");
  const [selected, setSelected] = useState<OptionKey | null>(null);
  const [locked, setLocked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showCountdown, setShowCountdown] = useState(true);
  const serviceRef = useRef<ReturnType<typeof createDuelService> | null>(null);

  useEffect(() => {
    if (!isReady || !isAuthenticated) return;
    const service = createDuelService({
      onConnection: setConnection,
      onError: setError,
      onSnapshot: (patch) => {
        setSnapshot((prev) => ({ ...prev, ...patch }));
        if (patch.question) {
          setSelected(null);
          setLocked(false);
        }
      },
    });
    serviceRef.current = service;
    service.connect();
    return () => {
      service.disconnect();
      serviceRef.current = null;
    };
  }, [isReady, isAuthenticated]);

  const submit = useCallback(
    (choice: OptionKey) => {
      if (locked || !snapshot.question) return;
      setSelected(choice);
      setLocked(true);
      const sent = serviceRef.current?.submitAnswer(snapshot.question.id, choice);
      if (!sent) setError("Answer could not be sent. Reconnecting…");
    },
    [locked, snapshot.question],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (["a", "b", "c", "d"].includes(key)) submit(key as OptionKey);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [submit]);

  useEffect(() => {
    if (!snapshot.finished) return;
    const rating = user?.rating ?? 1400;
    const won = snapshot.myScore >= snapshot.opponentScore;
    resultsStore.saveDuel({
      duelId: id,
      myScore: snapshot.myScore,
      opponentScore: snapshot.opponentScore,
      opponentName: snapshot.opponentName ?? "Opponent",
      total: snapshot.total,
      ratingBefore: rating,
      ratingAfter: rating + (won ? 18 : -14),
      xpGained: won ? 120 : 40,
    });
    void navigate({ to: "/duel/$id/result", params: { id }, replace: true });
  }, [snapshot, id, navigate, user]);

  if (!isReady || !isAuthenticated) return <LoadingState label="Loading duel…" />;

  const progress = snapshot.total > 0 ? ((snapshot.index + 1) / snapshot.total) * 100 : 0;

  return (
    <main className="flex min-h-screen flex-col bg-background">
      {showCountdown ? <Countdown onDone={() => setShowCountdown(false)} /> : null}

      <header className="border-b border-border px-4 py-3">
        <div className="mx-auto grid max-w-4xl grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] items-center gap-3">
          <PlayerBar name={user?.name || user?.username || "You"} rating={user?.rating ?? null} score={snapshot.myScore} />
          <span className="numeric text-xs font-bold text-muted-foreground">VS</span>
          <PlayerBar
            name={snapshot.opponentName ?? "Opponent"}
            rating={null}
            score={snapshot.opponentScore}
            align="right"
          />
        </div>
        <div className="mx-auto mt-3 max-w-4xl">
          <Progress value={progress} className="h-1" />
          {snapshot.total > 0 ? (
            <p className="numeric mt-1 text-center text-[11px] text-muted-foreground">
              Question {snapshot.index + 1}/{snapshot.total}
            </p>
          ) : null}
        </div>
      </header>

      <section className="mx-auto flex w-full max-w-3xl flex-1 flex-col justify-center px-4 py-6">
        {snapshot.question ? (
          /* Correct answer is never passed while the question is live. */
          <QuestionPanel question={snapshot.question} selected={selected} disabled={locked} onSelect={submit} />
        ) : (
          <div className="text-center">
            <LoadingState label={connection === "OPEN" ? "Waiting for the first question…" : "Connecting to the duel…"} />
          </div>
        )}
        {error ? (
          <p role="alert" className="mt-4 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </p>
        ) : null}
      </section>

      <footer className="safe-bottom border-t border-border px-4 py-3">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3">
          <ConnectionIndicator state={connection} />
          <p className="hidden text-xs text-muted-foreground sm:block">Press A · B · C · D to answer</p>
          <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={() => void navigate({ to: "/arena" })}>
            <Flag className="mr-2 h-3.5 w-3.5" /> Leave
          </Button>
        </div>
      </footer>
    </main>
  );
}

function PlayerBar({
  name,
  rating,
  score,
  align = "left",
}: {
  name: string;
  rating: number | null;
  score: number;
  align?: "left" | "right";
}) {
  return (
    <div className={`flex min-w-0 items-center gap-2 ${align === "right" ? "flex-row-reverse text-right" : ""}`}>
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-border bg-card text-[10px] font-bold text-primary">
        {initialsOf(name)}
      </div>
      <div className="min-w-0">
        <p className="truncate text-xs font-semibold sm:text-sm">{name}</p>
        <p className="label-micro">{rating != null ? `${rating}` : "UNRATED"}</p>
      </div>
      <span className="numeric shrink-0 text-lg font-bold text-primary sm:text-xl">{score}</span>
    </div>
  );
}
