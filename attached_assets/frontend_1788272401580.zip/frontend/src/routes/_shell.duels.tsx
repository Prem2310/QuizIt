import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Lock, Swords } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TOPICS, MATCHMAKING_FIXED } from "@/constants/topics";
import { quizService } from "@/services/quiz";
import { useAuth } from "@/stores/auth";
import { ApiError } from "@/lib/api";

export const Route = createFileRoute("/_shell/duels")({
  head: () => ({
    meta: [
      { title: "Duels — QuizIt" },
      { name: "description", content: "Start a ranked quick match or challenge a friend to a private QuizIt duel." },
      { property: "og:title", content: "Duels — QuizIt" },
      { property: "og:description", content: "Start a ranked quick match or challenge a friend to a private duel." },
    ],
  }),
  component: DuelsPage,
});

const schema = z.object({
  opponent: z.string().min(2, "Enter your friend's username"),
  topicName: z.string().min(1),
  numQuestions: z.coerce.number().min(2).max(20),
  timePerQuestion: z.coerce.number().min(10).max(120),
});
type FormValues = z.input<typeof schema>;

function DuelsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { opponent: "", topicName: "DSA", numQuestions: 5, timePerQuestion: 30 },
  });

  const onSubmit = async (values: FormValues) => {
    setError(null);
    try {
      // Real backend: POST /quiz/create-quiz (random mode only).
      await quizService.createQuiz({
        topicName: String(values.topicName),
        numQuestions: Number(values.numQuestions),
        usernames: [user?.username ?? "", String(values.opponent)].filter(Boolean),
        timePerQuestion: Number(values.timePerQuestion),
        quizMode: "random",
      });
      toast.success("Quiz created. Opening the duel room…");
      void navigate({ to: "/duel/$id", params: { id: "current" } });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create the duel.");
    }
  };

  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Head to head" title="Duels" description="Race an opponent question by question." />

      <section className="surface-panel grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 p-6 sm:flex sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Swords className="h-5 w-5 shrink-0 text-primary" />
            <p className="text-base font-semibold">Quick Match</p>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Ranked matchmaking. Currently fixed by the backend to {MATCHMAKING_FIXED.topic} ·{" "}
            {MATCHMAKING_FIXED.numQuestions} questions.
          </p>
        </div>
        <Button asChild className="h-11 shrink-0 px-5 font-semibold">
          <Link to="/matchmaking">Find opponent</Link>
        </Button>
      </section>

      <section className="surface-panel p-6">
        <p className="label-micro">Challenge a friend</p>
        <h2 className="mt-1 text-lg font-semibold">Create a private quiz</h2>
        <form className="mt-5 grid gap-4 sm:grid-cols-2" onSubmit={form.handleSubmit(onSubmit)} noValidate>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="opponent">Friend's username</Label>
            <Input id="opponent" placeholder="ishita" {...form.register("opponent")} />
            {form.formState.errors.opponent ? (
              <p className="text-xs text-destructive">{form.formState.errors.opponent.message}</p>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="topicName">Topic</Label>
            <Select
              defaultValue="DSA"
              onValueChange={(v) => form.setValue("topicName", v)}
            >
              <SelectTrigger id="topicName" className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TOPICS.map((t) => (
                  <SelectItem key={t.slug} value={t.backendName}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="numQuestions">Questions</Label>
            <Input id="numQuestions" type="number" min={2} max={20} {...form.register("numQuestions")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="timePerQuestion">Seconds per question</Label>
            <Input id="timePerQuestion" type="number" min={10} max={120} {...form.register("timePerQuestion")} />
          </div>
          <div className="space-y-2">
            <Label>Quiz mode</Label>
            <div className="flex flex-wrap gap-2">
              <Badge className="h-9 rounded-lg px-3 text-xs">Random</Badge>
              <Badge variant="outline" className="h-9 gap-1 rounded-lg border-border px-3 text-xs text-muted-foreground">
                <Lock className="h-3 w-3" /> AI · Coming soon
              </Badge>
              <Badge variant="outline" className="h-9 gap-1 rounded-lg border-border px-3 text-xs text-muted-foreground">
                <Lock className="h-3 w-3" /> Custom · Coming soon
              </Badge>
            </div>
          </div>
          {error ? (
            <p role="alert" className="sm:col-span-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          ) : null}
          <Button type="submit" className="h-12 sm:col-span-2" disabled={form.formState.isSubmitting}>
            {form.formState.isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Create duel
          </Button>
        </form>
      </section>
    </div>
  );
}
