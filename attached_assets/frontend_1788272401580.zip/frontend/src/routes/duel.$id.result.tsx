import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { AnimatedNumber } from "@/components/common/AnimatedNumber";
import { EmptyState } from "@/components/common/StateBlocks";
import { resultsStore, type DuelResultSummary } from "@/stores/results";
import { useRequireAuth } from "@/hooks/useRequireAuth";

export const Route = createFileRoute("/duel/$id/result")({
  head: () => ({
    meta: [
      { title: "Duel result — QuizIt" },
      { name: "description", content: "See how your QuizIt duel finished: score, rating change and XP earned." },
      { property: "og:title", content: "Duel result — QuizIt" },
      { property: "og:description", content: "See how your QuizIt duel finished: score, rating change and XP earned." },
    ],
  }),
  component: DuelResultPage,
});

function DuelResultPage() {
  useRequireAuth();
  const [result, setResult] = useState<DuelResultSummary | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setResult(resultsStore.loadDuel());
    setReady(true);
  }, []);

  if (!ready) return null;

  if (!result) {
    return (
      <main className="mx-auto max-w-lg px-4 py-16">
        <EmptyState
          title="No duel result"
          message="Finish a duel to see the summary here."
          action={
            <Button asChild size="sm">
              <Link to="/matchmaking">Find a duel</Link>
            </Button>
          }
        />
      </main>
    );
  }

  const won = result.myScore > result.opponentScore;
  const draw = result.myScore === result.opponentScore;
  const heading = draw ? "Draw" : won ? "Victory" : "Defeat";

  const rows = [
    { label: "Your score", value: result.myScore },
    { label: `${result.opponentName}`, value: result.opponentScore },
    { label: "Questions", value: result.total },
  ];

  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col justify-center px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="surface-panel p-6 text-center">
        <p className="label-micro">Duel complete</p>
        <h1 className={`mt-2 text-4xl font-bold ${won ? "text-primary" : draw ? "text-foreground" : "text-destructive"}`}>
          {heading}
        </h1>
        <p className="numeric mt-4 text-3xl font-bold">
          {result.myScore} <span className="text-muted-foreground">–</span> {result.opponentScore}
        </p>

        <div className="mt-6 grid gap-2">
          {rows.map((row, i) => (
            <motion.div
              key={row.label}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.08 * i }}
              className="flex items-center justify-between rounded-lg border border-border bg-surface px-3 py-2 text-sm"
            >
              <span className="min-w-0 truncate text-muted-foreground">{row.label}</span>
              <span className="numeric font-semibold">{row.value}</span>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border bg-surface p-3">
            <p className="label-micro">Rating</p>
            <p className="numeric mt-1 text-xl font-bold text-foreground">
              <AnimatedNumber value={result.ratingAfter} from={result.ratingBefore} />
            </p>
          </div>
          <div className="rounded-lg border border-border bg-surface p-3">
            <p className="label-micro">XP earned</p>
            <p className="numeric mt-1 text-xl font-bold text-primary">
              +<AnimatedNumber value={result.xpGained} />
            </p>
          </div>
        </div>
        <p className="mt-3 text-[11px] text-muted-foreground">
          Rating and XP changes are estimated on the client — the backend does not expose a duel summary endpoint yet.
        </p>

        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button asChild className="h-11 px-6 font-bold tracking-wide">
            <Link to="/matchmaking">PLAY AGAIN</Link>
          </Button>
          <Button asChild variant="outline" className="h-11 px-6">
            <Link to="/arena">Back to arena</Link>
          </Button>
        </div>
      </motion.div>
    </main>
  );
}
