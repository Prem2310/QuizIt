import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Crown } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { DemoBadge, ErrorState } from "@/components/common/StateBlocks";
import { mockLeaderboardService, type LeaderboardScope } from "@/services/mockLeaderboardService";
import { useAuth } from "@/stores/auth";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_shell/leaderboard")({
  head: () => ({
    meta: [
      { title: "Leaderboard — QuizIt" },
      { name: "description", content: "See the top QuizIt players globally, weekly, by college and among friends." },
      { property: "og:title", content: "Leaderboard — QuizIt" },
      { property: "og:description", content: "See the top QuizIt players globally, weekly, by college and among friends." },
    ],
  }),
  component: LeaderboardPage,
});

const SCOPES: Array<{ id: LeaderboardScope; label: string }> = [
  { id: "global", label: "Global" },
  { id: "weekly", label: "Weekly" },
  { id: "college", label: "College" },
  { id: "friends", label: "Friends" },
];

function LeaderboardPage() {
  const { user } = useAuth();
  const [scope, setScope] = useState<LeaderboardScope>("global");

  // TODO: Replace demo leaderboard provider with backend endpoint when implemented.
  const { data, isPending, isError, refetch } = useQuery({
    queryKey: ["leaderboard", scope],
    queryFn: () => mockLeaderboardService.getLeaderboard(scope),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Standings"
        title="Leaderboard"
        description="Ranked by rating across the QuizIt arena."
        actions={<DemoBadge />}
      />

      <Tabs value={scope} onValueChange={(v) => setScope(v as LeaderboardScope)}>
        <TabsList className="grid w-full grid-cols-4 bg-surface">
          {SCOPES.map((s) => (
            <TabsTrigger key={s.id} value={s.id} className="text-xs sm:text-sm">
              {s.label}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {isError ? (
        <ErrorState message="Leaderboard could not be loaded." onRetry={() => void refetch()} />
      ) : isPending ? (
        <div className="space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full rounded-xl bg-card" />
          ))}
        </div>
      ) : (
        <ol className="space-y-2">
          {data.map((entry) => {
            const isMe = user?.username === entry.username;
            return (
              <li
                key={entry.username}
                className={cn(
                  "surface-panel grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-3 px-3 py-3 sm:px-4",
                  isMe && "border-primary/60 bg-primary/5",
                )}
              >
                <span
                  className={cn(
                    "numeric text-sm font-bold",
                    entry.rank === 1 ? "text-warning" : entry.rank <= 3 ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  {entry.rank === 1 ? <Crown className="h-4 w-4 text-warning" /> : entry.rank}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{entry.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    @{entry.username}
                    {entry.college ? ` · ${entry.college}` : ""}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="numeric text-sm font-bold text-primary">{entry.rating}</p>
                  <p className="label-micro">{entry.accuracy}% ACC</p>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
