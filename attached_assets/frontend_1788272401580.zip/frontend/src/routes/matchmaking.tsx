import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConnectionIndicator } from "@/components/common/StateBlocks";
import { Badge } from "@/components/ui/badge";
import { LogoMark } from "@/components/brand/Logo";
import { useRequireAuth } from "@/hooks/useRequireAuth";
import { useAuth } from "@/stores/auth";
import { createMatchmakingService } from "@/services/matchmaking";
import { MATCHMAKING_FIXED } from "@/constants/topics";
import { initialsOf } from "@/components/layout/AppShell";
import type { ConnectionState, MatchmakingState } from "@/types";

export const Route = createFileRoute("/matchmaking")({
  head: () => ({
    meta: [
      { title: "Finding opponent — QuizIt" },
      { name: "description", content: "QuizIt matchmaking: getting you into a live aptitude duel." },
      { property: "og:title", content: "Finding opponent — QuizIt" },
      { property: "og:description", content: "QuizIt matchmaking: getting you into a live aptitude duel." },
    ],
  }),
  component: MatchmakingPage,
});

function MatchmakingPage() {
  const { isReady, isAuthenticated } = useRequireAuth();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [state, setState] = useState<MatchmakingState>("IDLE");
  const [connection, setConnection] = useState<ConnectionState>("IDLE");
  const [elapsed, setElapsed] = useState(0);
  const [message, setMessage] = useState<string | null>(null);
  const [opponent, setOpponent] = useState<string | null>(null);
  const serviceRef = useRef<ReturnType<typeof createMatchmakingService> | null>(null);

  useEffect(() => {
    if (!isReady || !isAuthenticated) return;
    const service = createMatchmakingService({
      onState: setState,
      onConnection: setConnection,
      onError: setMessage,
      onMatchFound: (payload) => {
        setOpponent(payload.opponent?.username ?? "Opponent");
        setTimeout(() => {
          void navigate({ to: "/duel/$id", params: { id: payload.roomId ?? "current" } });
        }, 1200);
      },
    });
    serviceRef.current = service;
    service.start();
    return () => {
      service.dispose();
      serviceRef.current = null;
    };
  }, [isReady, isAuthenticated, navigate]);

  useEffect(() => {
    if (state !== "SEARCHING") return;
    const id = setInterval(() => setElapsed((v) => v + 1), 1000);
    return () => clearInterval(id);
  }, [state]);

  const cancel = () => {
    serviceRef.current?.cancel();
    void navigate({ to: "/arena" });
  };

  const mm = `${String(Math.floor(elapsed / 60)).padStart(2, "0")}:${String(elapsed % 60).padStart(2, "0")}`;
  const matched = state === "MATCH_FOUND";

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background px-4 py-10">
      <p className="label-micro">{matched ? "Match found" : "Finding opponent"}</p>
      <h1 className="mt-2 text-center text-2xl font-bold sm:text-3xl">
        {matched ? "Opponent locked in" : "Searching the arena…"}
      </h1>

      <div className="relative mt-10 flex h-44 w-44 items-center justify-center">
        {!matched ? (
          <>
            <span className="radar-ring absolute inset-0 rounded-full border border-primary/40" />
            <span className="radar-ring absolute inset-0 rounded-full border border-primary/30" style={{ animationDelay: "0.8s" }} />
            <span className="radar-ring absolute inset-0 rounded-full border border-primary/20" style={{ animationDelay: "1.6s" }} />
          </>
        ) : null}
        <div className="flex h-24 w-24 items-center justify-center rounded-full border border-border bg-card">
          <LogoMark className="h-9 w-9" />
        </div>
      </div>

      <div className="mt-10 grid w-full max-w-md grid-cols-2 gap-3">
        <PlayerCard name={user?.name || user?.username || "You"} rating={user?.rating ?? null} side="left" />
        <PlayerCard name={opponent ?? "Searching…"} rating={null} side="right" revealed={matched} />
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-muted-foreground">
        <Badge variant="outline" className="border-border text-muted-foreground">
          Ranked
        </Badge>
        <Badge variant="outline" className="border-border text-muted-foreground">
          {MATCHMAKING_FIXED.topic} · {MATCHMAKING_FIXED.numQuestions} questions
        </Badge>
        <span className="numeric">{mm}</span>
        <ConnectionIndicator state={connection} />
      </div>
      <p className="mt-3 max-w-sm text-center text-xs text-muted-foreground">
        Matchmaking filters (topic, length, difficulty) are not supported by the backend yet — every quick match is{" "}
        {MATCHMAKING_FIXED.topic} with {MATCHMAKING_FIXED.numQuestions} questions.
      </p>

      {message ? (
        <p role="alert" className="mt-4 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {message}
        </p>
      ) : null}

      <Button variant="outline" className="mt-8 h-11 px-6" onClick={cancel}>
        <X className="mr-2 h-4 w-4" /> Cancel
      </Button>
    </main>
  );
}

function PlayerCard({
  name,
  rating,
  side,
  revealed = true,
}: {
  name: string;
  rating: number | null;
  side: "left" | "right";
  revealed?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: side === "left" ? -24 : 24 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
      className="surface-panel flex flex-col items-center gap-1 p-4"
    >
      <div className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface text-xs font-bold text-primary">
        {revealed ? initialsOf(name) : "?"}
      </div>
      <p className="mt-1 max-w-full truncate text-sm font-semibold">{name}</p>
      <p className="label-micro">{rating != null ? `${rating} RATING` : "UNRATED"}</p>
    </motion.div>
  );
}
