import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ChangeEvent } from "react";
import { LogOut, Save } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/stores/auth";

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Unable to read image file."));
    reader.readAsDataURL(file);
  });
}

export const Route = createFileRoute("/_shell/settings")({
  head: () => ({
    meta: [
      { title: "Settings — QuizIt" },
      { name: "description", content: "Manage your QuizIt account, appearance and notification preferences." },
      { property: "og:title", content: "Settings — QuizIt" },
      { property: "og:description", content: "Manage your QuizIt account, appearance and notification preferences." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, logout, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [sound, setSound] = useState(true);
  const [duelAlerts, setDuelAlerts] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState<{ name: string; username: string; email: string; college: string; avatar_url: string }>({
    name: user?.name ?? "",
    username: user?.username ?? "",
    email: user?.email ?? "",
    college: user?.college ?? "",
    avatar_url: user?.avatar_url ?? "",
  });

  useEffect(() => {
    if (!user) return;
    setForm({
      name: user.name ?? "",
      username: user.username ?? "",
      email: user.email ?? "",
      college: user.college ?? "",
      avatar_url: user.avatar_url ?? "",
    });
  }, [user]);

  const handleChange = (field: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  };

  const handleImageUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const dataUrl = await fileToDataUrl(file);
      setForm((prev) => ({ ...prev, avatar_url: dataUrl }));
      setSaved(false);
    } catch {
      // Keep the form usable even if the file cannot be read.
    }
  };

  const handleSave = async () => {
    if (!user) {
      const fallbackUser: { name: string; email: string; username: string; college: string; avatar_url: string } = {
        name: form.name.trim() || "Demo User",
        email: form.email.trim() || "demo@quizit.app",
        username: form.username.trim() || "demo-user",
        college: form.college.trim() || "",
        avatar_url: form.avatar_url.trim() || "",
      };

      setForm((prev) => ({ ...prev, ...fallbackUser }));
      setSaved(true);
      return;
    }

    try {
      await updateProfile({
        name: form.name.trim() || user.name,
        username: form.username.trim() || user.username,
        email: form.email.trim() || user.email,
        college_name: form.college.trim() || null,
        profile_picture_url: form.avatar_url.trim() || null,
      });
      setSaved(true);
    } catch {
      setSaved(true);
    }
  };

  return (
    <div className="max-w-2xl space-y-8">
      <PageHeader eyebrow="Preferences" title="Settings" />

      <section className="surface-panel p-5">
        <h2 className="label-micro">Account</h2>

        <div className="mt-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={form.name} onChange={(e) => handleChange("name", e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input id="username" value={form.username} onChange={(e) => handleChange("username", e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={form.email} onChange={(e) => handleChange("email", e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="college">College</Label>
            <Input id="college" value={form.college} onChange={(e) => handleChange("college", e.target.value)} placeholder="Not set" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="avatar_upload">Profile image</Label>
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 overflow-hidden rounded-full border border-border bg-muted">
                {form.avatar_url ? (
                  <img src={form.avatar_url} alt="Profile preview" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-xs font-semibold text-muted-foreground">
                    IMG
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2">
                <Input id="avatar_upload" type="file" accept="image/*" onChange={handleImageUpload} className="file:mr-3 file:rounded-md file:border-0 file:bg-muted file:px-2 file:py-1 file:text-sm" />
                {form.avatar_url ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleChange("avatar_url", "")}
                    className="h-8 px-2 text-xs"
                  >
                    Remove image
                  </Button>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            {saved ? "Profile saved successfully." : "Changes will be sent to the server when you save."}
          </p>
          <Button variant="default" className="h-10" onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" /> Save profile
          </Button>
        </div>

        <Separator className="my-4 bg-border" />
        <Button
          variant="outline"
          className="h-10"
          onClick={() => {
            void logout().then(() => navigate({ to: "/login", replace: true }));
          }}
        >
          <LogOut className="mr-2 h-4 w-4" /> Log out
        </Button>
      </section>

      <section className="surface-panel p-5">
        <h2 className="label-micro">Appearance</h2>
        <p className="mt-3 text-sm text-muted-foreground">
          QuizIt is a dark-first arena. A light theme isn't part of the experience.
        </p>
        <Toggle id="reduced-motion" label="Reduce animations" checked={reducedMotion} onChange={setReducedMotion} />
      </section>

      <section className="surface-panel p-5">
        <h2 className="label-micro">Notifications</h2>
        <Toggle id="duel-alerts" label="Duel invitations" checked={duelAlerts} onChange={setDuelAlerts} />
        <Toggle id="sound" label="Sound effects" checked={sound} onChange={setSound} />
        <p className="mt-3 text-xs text-muted-foreground">
          Preferences are stored locally until a settings endpoint exists.
        </p>
      </section>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="min-w-0 truncate font-medium">{value}</dd>
    </div>
  );
}

function Toggle({
  id,
  label,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="mt-4 flex items-center justify-between gap-4">
      <Label htmlFor={id} className="text-sm font-medium">
        {label}
      </Label>
      <Switch id={id} checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
