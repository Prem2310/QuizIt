import { createFileRoute, Link } from "@tanstack/react-router";
import { Flame, Target, Timer, Users } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { DemoBadge } from "@/components/common/StateBlocks";
import { mockEngagementService } from "@/services/mockEngagementService";
import { TOPICS } from "@/constants/topics";

export const Route = createFileRoute("/_shell/challenges")({
  head: () => ({
    meta: [
      { title: "Challenges — QuizIt" },
      { name: "description", content: "Daily and weekly QuizIt challenges to keep your streak alive." },
      { property: "og:title", content: "Challenges — QuizIt" },
      { property: "og:description", content: "Daily and weekly QuizIt challenges to keep your streak alive." },
    ],
  }),
  component: ChallengesPage,
});

function ChallengesPage() {
  const daily = mockEngagementService.getDailyChallenge();
  const engagement = mockEngagementService.getSummary();
  const dailyTopic = TOPICS.find((t) => t.backendName === daily.topicBackendName) ?? TOPICS[1]!;

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Keep the streak"
        title="Challenges"
        description="Daily sets that use real backend questions."
        actions={
          <span className="flex items-center gap-1.5 text-sm font-semibold text-warning">
            <Flame className="h-4 w-4" /> {engagement.streakDays} days
          </span>
        }
      />

      <section className="surface-panel p-6">
        <div className="flex items-center justify-between gap-3">
          <p className="label-micro">Today's challenge</p>
          <DemoBadge />
        </div>
        <h2 className="mt-2 text-xl font-bold">{daily.title}</h2>
        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Target className="h-3.5 w-3.5" /> {daily.questions} questions
          </span>
          <span className="flex items-center gap-1">
            <Timer className="h-3.5 w-3.5" /> {daily.durationLabel}
          </span>
          <span className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5" /> {daily.playersToday.toLocaleString()} players today
          </span>
        </div>
        <Button asChild className="mt-6 h-12 px-6 font-bold tracking-wide">
          <Link to="/practice/$topic" params={{ topic: dailyTopic.slug }}>
            START CHALLENGE
          </Link>
        </Button>
        <p className="mt-3 text-xs text-muted-foreground">
          Challenge metadata is demo data; the questions come from the real MCQ endpoint.
        </p>
      </section>

      <section className="surface-panel p-6">
        <p className="label-micro">Weekly ladder</p>
        <p className="mt-2 text-sm text-muted-foreground">
          Weekly challenge ladders need a backend endpoint.
          <br />
          TODO: Replace with real challenge data when implemented.
        </p>
      </section>
    </div>
  );
}
