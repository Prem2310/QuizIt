import { useMemo } from "react";
import DOMPurify from "dompurify";

interface Props {
  html: string;
  className?: string;
}

/**
 * Renders HTML content safely using DOMPurify to sanitize and prevent XSS.
 * Allows images, links, and basic formatting while blocking scripts.
 */
export function SafeHtml({ html, className = "" }: Props) {
  const sanitized = useMemo(() => {
    const config = {
      ALLOWED_TAGS: ["p", "br", "strong", "em", "u", "a", "img", "div", "span", "ul", "ol", "li", "h1", "h2", "h3", "h4", "h5", "h6"],
      ALLOWED_ATTR: ["src", "alt", "href", "title", "class", "id", "style", "width", "height"],
      ALLOW_DATA_ATTR: false,
      KEEP_CONTENT: true,
    };
    return DOMPurify.sanitize(html, config);
  }, [html]);

  return (
    <div
      className={className}
      dangerouslySetInnerHTML={{ __html: sanitized }}
    />
  );
}
