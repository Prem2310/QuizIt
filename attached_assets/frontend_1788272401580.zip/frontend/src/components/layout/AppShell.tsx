import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  Flame,
  Gamepad2,
  LogOut,
  Settings,
  Swords,
  Target,
  Trophy,
  User as UserIcon,
  Zap,
} from "lucide-react";
import type { ReactNode } from "react";
import { Logo, LogoMark } from "@/components/brand/Logo";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { useAuth } from "@/stores/auth";
import { mockEngagementService } from "@/services/mockEngagementService";

type NavPath =
  | "/arena"
  | "/duels"
  | "/practice"
  | "/challenges"
  | "/leaderboard"
  | "/progress"
  | "/profile"
  | "/settings";

const PRIMARY_NAV: Array<{ to: NavPath; label: string; icon: typeof Gamepad2 }> = [
  { to: "/arena", label: "Arena", icon: Gamepad2 },
  { to: "/duels", label: "Duels", icon: Swords },
  { to: "/practice", label: "Practice", icon: Target },
  { to: "/challenges", label: "Challenges", icon: Flame },
  { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/progress", label: "Progress", icon: BarChart3 },
];

const SECONDARY_NAV: Array<{ to: NavPath; label: string; icon: typeof Gamepad2 }> = [
  { to: "/profile", label: "Profile", icon: UserIcon },
  { to: "/settings", label: "Settings", icon: Settings },
];

const MOBILE_NAV: Array<{ to: NavPath; label: string; icon: typeof Gamepad2 }> = [
  { to: "/arena", label: "Arena", icon: Gamepad2 },
  { to: "/duels", label: "Duel", icon: Swords },
  { to: "/practice", label: "Practice", icon: Target },
  { to: "/leaderboard", label: "Ranks", icon: Trophy },
  { to: "/profile", label: "Profile", icon: UserIcon },
];

export function initialsOf(value: string): string {
  const parts = value.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "Q";
  return (parts[0]![0]! + (parts[1]?.[0] ?? "")).toUpperCase();
}

function NavItem({ to, label, icon: Icon, active }: { to: NavPath; label: string; icon: typeof Gamepad2; active: boolean }) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-surface hover:text-foreground",
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      <span className="truncate">{label}</span>
    </Link>
  );
}

export function AppShell({ children, bare = false }: { children: ReactNode; bare?: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { user, logout } = useAuth();
  const engagement = mockEngagementService.getSummary();
  const displayName = user?.name || user?.username || "Player";

  if (bare) {
    return <main className="min-h-screen bg-background">{children}</main>;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-border bg-surface-2 lg:flex">
        <div className="px-5 py-5">
          <Logo />
        </div>
        <nav className="flex flex-1 flex-col gap-1 px-3" aria-label="Main">
          {PRIMARY_NAV.map((item) => (
            <NavItem key={item.to} {...item} active={pathname.startsWith(item.to)} />
          ))}
          <Separator className="my-3 bg-border" />
          {SECONDARY_NAV.map((item) => (
            <NavItem key={item.to} {...item} active={pathname.startsWith(item.to)} />
          ))}
        </nav>
        <div className="border-t border-border p-3">
          <div className="flex items-center gap-3 rounded-lg px-2 py-2">
            <Avatar className="h-9 w-9 shrink-0 border border-border">
              <AvatarFallback className="bg-card text-xs font-semibold text-primary">
                {initialsOf(displayName)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground">{displayName}</p>
              <p className="label-micro">{user?.rating != null ? `${user.rating} RATING` : "UNRATED"}</p>
            </div>
            <button
              type="button"
              onClick={() => void logout()}
              aria-label="Log out"
              className="rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-card hover:text-destructive"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
        <Link to="/arena" className="flex items-center gap-2">
          <LogoMark className="h-6 w-6" />
          <span className="font-display text-base font-bold tracking-[0.16em]">
            QUIZ<span className="text-primary">IT</span>
          </span>
        </Link>
        <div className="flex shrink-0 items-center gap-3">
          <span className="flex items-center gap-1 text-xs font-semibold text-warning">
            <Flame className="h-3.5 w-3.5" />
            {engagement.streakDays}
          </span>
          <span className="flex items-center gap-1 text-xs font-semibold text-primary">
            <Zap className="h-3.5 w-3.5" />
            {engagement.xp}
          </span>
          <Link to="/profile" aria-label="Profile">
            <Avatar className="h-7 w-7 border border-border">
              <AvatarFallback className="bg-card text-[10px] font-semibold text-primary">
                {initialsOf(displayName)}
              </AvatarFallback>
            </Avatar>
          </Link>
        </div>
      </header>

      <main className="min-h-screen pb-24 lg:ml-60 lg:pb-8">
        <div className="mx-auto w-full max-w-6xl px-4 py-5 sm:px-6 lg:py-8">{children}</div>
      </main>

      {/* Mobile bottom navigation */}
      <nav
        aria-label="Primary"
        className="safe-bottom fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-surface-2/95 pt-1.5 backdrop-blur lg:hidden"
      >
        {MOBILE_NAV.map(({ to, label, icon: Icon }) => {
          const active = pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                "flex min-h-[48px] flex-col items-center justify-center gap-1 text-[10px] font-semibold uppercase tracking-wider",
                active ? "text-primary" : "text-muted-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              {label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
