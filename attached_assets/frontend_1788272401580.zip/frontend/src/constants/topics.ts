import type { LucideIcon } from "lucide-react";
import {
  Binary,
  BookOpen,
  Brain,
  Calculator,
  Clock,
  Gauge,
  Grid3x3,
  LineChart,
  Percent,
  PuzzleIcon,
  Shuffle,
  Sigma,
  SpellCheck,
  TrendingUp,
  Users,
  Waypoints,
} from "lucide-react";

export type TopicCategory = "Quantitative" | "Reasoning" | "Verbal" | "Data" | "Programming";
export type TopicDifficulty = "Easy" | "Medium" | "Hard";

/**
 * FRONTEND-ONLY topic metadata.
 * The backend has no GET /topics endpoint yet, so display metadata lives here.
 * `backendName` is the exact string sent to the backend
 * (GET /mcqs/get_mcqs/{count}/{topic_name} and POST /quiz/create-quiz).
 * TODO: replace this constant with a real GET /topics response when available.
 */
export interface TopicMeta {
  slug: string;
  /** Exact topic name understood by the backend. */
  backendName: string;
  label: string;
  category: TopicCategory;
  difficulty: TopicDifficulty;
  icon: LucideIcon;
  blurb: string;
}

export const TOPICS: TopicMeta[] = [
  { slug: "dsa", backendName: "DSA", label: "DSA", category: "Programming", difficulty: "Hard", icon: Binary, blurb: "Data structures & algorithms drills" },
  { slug: "quantitative-aptitude", backendName: "Quantitative Aptitude", label: "Quantitative Aptitude", category: "Quantitative", difficulty: "Medium", icon: Calculator, blurb: "Core placement quant" },
  { slug: "logical-reasoning", backendName: "Logical Reasoning", label: "Logical Reasoning", category: "Reasoning", difficulty: "Medium", icon: Brain, blurb: "Deduction and pattern logic" },
  { slug: "verbal-ability", backendName: "Verbal Ability", label: "Verbal Ability", category: "Verbal", difficulty: "Easy", icon: SpellCheck, blurb: "Grammar, usage, vocabulary" },
  { slug: "data-interpretation", backendName: "Data Interpretation", label: "Data Interpretation", category: "Data", difficulty: "Hard", icon: LineChart, blurb: "Charts, tables, caselets" },
  { slug: "probability", backendName: "Probability", label: "Probability", category: "Quantitative", difficulty: "Hard", icon: Sigma, blurb: "Chance and combinatorics" },
  { slug: "number-system", backendName: "Number System", label: "Number System", category: "Quantitative", difficulty: "Medium", icon: Waypoints, blurb: "Divisibility, remainders, HCF" },
  { slug: "percentage", backendName: "Percentage", label: "Percentage", category: "Quantitative", difficulty: "Easy", icon: Percent, blurb: "Ratios and percentage change" },
  { slug: "profit-loss", backendName: "Profit & Loss", label: "Profit & Loss", category: "Quantitative", difficulty: "Medium", icon: TrendingUp, blurb: "Cost, margin, discount" },
  { slug: "time-work", backendName: "Time & Work", label: "Time & Work", category: "Quantitative", difficulty: "Medium", icon: Clock, blurb: "Work rate problems" },
  { slug: "time-speed-distance", backendName: "Time Speed Distance", label: "Time Speed Distance", category: "Quantitative", difficulty: "Medium", icon: Gauge, blurb: "Motion, trains, boats" },
  { slug: "coding-decoding", backendName: "Coding-Decoding", label: "Coding-Decoding", category: "Reasoning", difficulty: "Easy", icon: Shuffle, blurb: "Letter and number codes" },
  { slug: "series", backendName: "Series", label: "Series", category: "Reasoning", difficulty: "Medium", icon: Waypoints, blurb: "Number and letter series" },
  { slug: "puzzles", backendName: "Puzzles", label: "Puzzles", category: "Reasoning", difficulty: "Hard", icon: PuzzleIcon, blurb: "Grid and logic puzzles" },
  { slug: "syllogism", backendName: "Syllogism", label: "Syllogism", category: "Reasoning", difficulty: "Medium", icon: Grid3x3, blurb: "Statements and conclusions" },
  { slug: "seating-arrangement", backendName: "Seating Arrangement", label: "Seating Arrangement", category: "Reasoning", difficulty: "Hard", icon: Users, blurb: "Linear and circular seating" },
  { slug: "reading-comprehension", backendName: "Reading Comprehension", label: "Reading Comprehension", category: "Verbal", difficulty: "Medium", icon: BookOpen, blurb: "Passage based questions" },
];

export const TOPIC_CATEGORIES: TopicCategory[] = [
  "Quantitative",
  "Reasoning",
  "Verbal",
  "Data",
  "Programming",
];

export function getTopicBySlug(slug: string): TopicMeta | undefined {
  return TOPICS.find((t) => t.slug === slug);
}

/** Matchmaking is currently hardcoded on the backend to DSA / 2 questions. */
export const MATCHMAKING_FIXED = {
  topic: "DSA",
  numQuestions: 2,
} as const;
