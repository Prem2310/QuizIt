# QuizIt Arena

Build a production-quality responsive frontend for a competitive aptitude and brain-battle web application called "QuizIt".

IMPORTANT:

This project already has an existing FastAPI + PostgreSQL + Redis + WebSocket backend.

DO NOT create a new backend.

DO NOT create a Supabase backend.

DO NOT replace the existing database.

DO NOT invent APIs that do not exist.

DO NOT modify backend code.

Your job is to build ONLY the frontend and integrate it with the existing backend.

==================================================

PRODUCT

==================================================

QuizIt is a competitive aptitude platform inspired by the interaction philosophy of modern brain-game products such as Matiks.

The product should feel like:

- a competitive game

- a brain-training arena

- a modern puzzle application

- an aptitude preparation platform

It should NOT feel like:

- a traditional LMS

- a school exam portal

- a corporate assessment dashboard

- a generic admin template

Core loop:

Practice → Compete → Improve → Earn XP/Rating → Leaderboard → Play Again

Primary users:

- college students

- placement aspirants

- aptitude learners

- competitive quiz players

Primary content:

- Quantitative Aptitude

- Logical Reasoning

- Verbal Ability

- Data Interpretation

- Probability

- Number System

- Percentages

- Profit & Loss

- Time & Work

- Time Speed Distance

- Coding-Decoding

- Series

- Puzzles

- Syllogism

- Seating Arrangement

- Reading Comprehension

==================================================

DESIGN DIRECTION

==================================================

Create a dark, minimal, premium, game-like interface.

Visual inspiration:

Take inspiration from the interaction philosophy and visual simplicity of modern brain-game apps such as Matiks:

- dark interface

- focused content

- game-mode cards

- competitive information

- daily challenges

- leaderboard

- streaks

- subtle animations

- strong typography

- minimal visual clutter

DO NOT copy Matiks branding, logos, exact layouts, artwork, icons, colors, or proprietary assets.

Create an original QuizIt identity.

==================================================

COLOR SYSTEM

==================================================

Primary background:

#080A09

Secondary background:

#0D110F

Surface:

#111713

Card:

#151C18

Border:

#25312A

Primary green:

#39D353

Bright green:

#7CFF6B

Muted green:

#1F6B3A

Primary text:

#F4F7F4

Secondary text:

#98A39C

Danger:

#EF4444

Warning:

#F59E0B

Success:

#39D353

Use green sparingly.

The UI should be approximately:

90% dark neutral

8% muted green

2% bright accent

Avoid excessive neon.

Avoid excessive gradients.

Avoid excessive glassmorphism.

Avoid huge shadows.

Avoid visual clutter.

==================================================

TYPOGRAPHY

==================================================

Use a modern sans-serif such as Inter for body/UI.

Use Space Grotesk or Sora for major headings if available.

Use:

- uppercase micro labels

- strong numeric typography

- generous spacing

- high contrast

Examples:

TODAY'S CHALLENGE

READY FOR A DUEL?

YOUR PROGRESS

LEADERBOARD

==================================================

UI PRINCIPLES

==================================================

1. Minimal

2. Fast

3. Competitive

4. Mobile-first

5. Highly readable

6. Keyboard accessible

7. Touch friendly

8. Responsive

9. Subtle motion

10. Never distract from the question

The question itself is the most important element during gameplay.

==================================================

TECH STACK

==================================================

Use:

React

TypeScript

Vite

Tailwind CSS

shadcn/ui

Lucide icons

Motion / Framer Motion where appropriate

React Hook Form

Zod

TanStack Query if useful

Use reusable components.

Do not duplicate UI code.

Create a clean frontend architecture.

==================================================

FRONTEND STRUCTURE

==================================================

Create something similar to:

src/

  components/

    ui/

    arena/

    quiz/

    duel/

    leaderboard/

    profile/

    progress/

  pages/

    Login

    Signup

    Arena

    Practice

    PracticeQuiz

    QuizResult

    Matchmaking

    DuelRoom

    DuelResult

    Leaderboard

    Progress

    Profile

    Settings

  hooks/

  lib/

    api.ts

    websocket.ts

  services/

    auth.ts

    quiz.ts

    topic.ts

    mcq.ts

    duel.ts

  stores/

  types/

  utils/

Keep API logic separate from UI.

==================================================

EXISTING BACKEND

==================================================

The existing FastAPI backend exposes:

REST:

POST /user/signup

POST /user/login

POST /topics/

POST /mcqs/bulk_insert

GET /mcqs/get_mcqs/{count}/{topic_name}

POST /quiz/create-quiz

WebSockets:

WS /duelroom/match-lobby

WS /duelroom/join-room-test

Backend uses PostgreSQL and Redis.

==================================================

AUTHENTICATION

==================================================

POST /user/signup

Request:

{

  "name": string,

  "email": string,

  "password": string,

  "username": string

}

POST /user/login

Request:

{

  "email": string,

  "password": string

}

Login response contains user information.

The backend sets an HTTP-only cookie called:

access_token

IMPORTANT:

The frontend must use credentials when calling the API because authentication is cookie-based.

For fetch:

credentials: "include"

For axios:

withCredentials: true

Do not attempt to read the access_token from JavaScript because it is HTTP-only.

Create:

auth service

login()

signup()

logout UI

current user state

There is currently no reliable backend logout endpoint.

Therefore implement logout as:

- clear frontend auth state

- optionally call a future logout endpoint only if it exists

- otherwise redirect to login

Do not invent a backend endpoint.

==================================================

API BASE URL

==================================================

Create environment variable:

VITE_API_BASE_URL

Example:

VITE_API_BASE_URL=http://localhost:8000

Never hardcode localhost throughout the application.

Create:

src/lib/api.ts

with a centralized API client.

All REST requests must use:

${VITE_API_BASE_URL}

and credentials included.

==================================================

TOPICS

==================================================

Existing backend supports:

POST /topics/

However, it does NOT currently provide a GET topics endpoint.

Therefore:

DO NOT invent GET /topics.

For the first version:

- provide a clean topic selector

- allow topics to be configured in a single frontend constants file

- use actual backend topic names when creating/fetching quizzes

Suggested topics:

DSA

Quantitative Aptitude

Logical Reasoning

Verbal Ability

Probability

Number System

Percentages

Profit & Loss

Time & Work

Time Speed Distance

Clearly separate frontend topic metadata from backend data.

==================================================

MCQ

==================================================

Existing endpoint:

GET /mcqs/get_mcqs/{count}/{topic_name}

Example:

GET /mcqs/get_mcqs/10/DSA

Response contains:

question_text

a

b

c

d

correct_option

topic_id

difficulty_level

explanation

IMPORTANT:

During active gameplay, NEVER show correct_option.

Treat correct_option as private/internal data.

Do not render it in the question UI.

==================================================

QUIZ CREATION

==================================================

Existing endpoint:

POST /quiz/create-quiz

Request:

{

  "topicName": string,

  "numQuestions": number,

  "usernames": string[],

  "timePerQuestion": number,

  "quizMode": "random" | "ai" | "custom"

}

For the current backend:

- random is the supported mode

- AI mode should be shown as "Coming Soon"

- custom mode should be shown as "Coming Soon"

Do not pretend AI/custom functionality exists.

==================================================

MATCHMAKING

==================================================

Existing backend WebSocket:

WS /duelroom/match-lobby

Authentication is cookie-based.

Connect using:

wss://YOUR_BACKEND/duelroom/match-lobby

or

ws://YOUR_BACKEND/duelroom/match-lobby

depending on environment.

Create a dedicated matchmaking WebSocket service.

States:

SEARCHING

MATCH_FOUND

ERROR

CANCELLED

DISCONNECTED

UI:

FINDING OPPONENT

Animated radar/pulse.

Show:

- current rating

- selected mode

- selected topic

- elapsed time

- cancel button

IMPORTANT:

The current backend matchmaking implementation is hardcoded to:

- DSA

- 2 questions

Do not build UI that falsely claims the backend currently supports arbitrary matchmaking filters.

The UI can display future filters, but clearly mark unsupported options as unavailable/coming soon.

==================================================

DUEL ROOM

==================================================

Existing backend WebSocket:

WS /duelroom/join-room-test

IMPORTANT:

Do NOT use the old frontend implementation:

/ws/duelroom/{roomId}

That endpoint does not exist in the current backend.

The frontend should create a new duel WebSocket service around:

/duelroom/join-room-test

The backend identifies the active quiz using the authenticated user's HTTP-only access_token cookie.

Do not put tokens in URLs.

==================================================

DUEL UI

==================================================

Create a polished competitive game interface.

Desktop:

Top:

- player name

- player rating

- opponent name

- opponent rating

- score

- question progress

Center:

- question

- four answer choices

- timer

Bottom:

- optional status

- keyboard shortcuts

- connection indicator

Mobile:

- player information at top

- progress bar

- question centered

- large touch-friendly answer buttons

- timer always visible

- no horizontal scrolling

Answer buttons:

- large

- minimum 48px touch target

- clear selected state

- correct/incorrect feedback

- subtle animation

Keyboard:

A

B

C

D

should select answers on desktop.

==================================================

GAME ANIMATIONS

==================================================

Use Motion / Framer Motion.

Use subtle animations:

Page:

fade + translateY

Cards:

hover translateY(-2px)

Buttons:

scale(0.98) on press

Correct:

green pulse + check

Incorrect:

short shake

Countdown:

3 → 2 → 1 → GO

Score:

animated number counter

XP:

+120 XP floating upward

Rating:

1428 → 1446 animated count

Match found:

player cards slide into place

Result:

staggered reveal

Do not animate everything.

Animations should improve feedback and hierarchy.

==================================================

ARENA / HOME

==================================================

Create the primary authenticated page as:

/arena

It should NOT look like a normal dashboard.

Layout:

Header:

QuizIt logo

streak

XP

avatar

Greeting:

"Good evening, Prem."

Hero CTA:

"READY FOR A CHALLENGE?"

Primary button:

"QUICK DUEL"

Daily Challenge card:

10 questions

2 minute challenge

players count

Play button

Duel section:

Quick Match

Challenge Friend

Practice:

Quantitative

Reasoning

Verbal

Progress:

Accuracy

Speed

Rating

Use responsive cards.

==================================================

DESKTOP SIDEBAR

==================================================

Persistent left sidebar:

QUIZIT

Arena

Duels

Practice

Challenges

Leaderboard

Progress

divider

Profile

Settings

At bottom:

user avatar

username

rating

Sidebar should collapse on smaller screens.

==================================================

MOBILE NAVIGATION

==================================================

Use fixed bottom navigation:

Arena

Duel

Practice

Leaderboard

Profile

Use icons + short labels.

Ensure safe-area padding on mobile.

==================================================

PRACTICE PAGE

==================================================

/practice

Show topic cards.

Each card:

icon

topic name

question count if available

difficulty

personal accuracy if available

Add:

- search

- category filter

- difficulty filter

For unsupported backend data, do not fabricate statistics.

==================================================

PRACTICE QUIZ

==================================================

/practice/:topic

Flow:

select number of questions

select difficulty

start

Then:

Question X/Y

timer

question

four options

next

skip

progress

After submission:

result page.

Use:

GET /mcqs/get_mcqs/{count}/{topic_name}

Do not send correct answers back to the server from the frontend as a scoring authority.

==================================================

RESULT PAGE

==================================================

Show:

Victory / Completed

Score

Accuracy

Correct

Incorrect

Skipped

Average response time

Question breakdown

For every question:

correct/incorrect

selected answer

correct answer

explanation

Only show correct answers AFTER the quiz has been submitted/completed.

==================================================

LEADERBOARD

==================================================

/leaderboard

Tabs:

Global

Weekly

College

Friends

IMPORTANT:

The existing backend does not currently expose leaderboard APIs.

Therefore build the complete UI using clearly marked mock/demo data behind a single adapter.

Do NOT create fake backend endpoints.

Add TODO comments explaining:

"Replace demo leaderboard provider with backend endpoint when implemented."

Do not mix mock data into components.

==================================================

PROGRESS

==================================================

/progress

Show:

Overall accuracy

Average response time

Current rating

XP

Matches played

Topic performance

Weak areas

Recent activity

Charts should be minimal and dark.

Do not create fake statistics for the authenticated user if the backend doesn't provide them.

==================================================

PROFILE

==================================================

/profile

Show:

avatar

name

username

college

rating

points

correct

incorrect

rank

These fields are available in the current login response.

Create a premium profile card.

==================================================

SETTINGS

==================================================

/settings

Sections:

Account

Appearance

Notifications

Appearance:

Dark theme should be the default.

Do not make light mode the primary experience.

==================================================

RESPONSIVE DESIGN

==================================================

This is mandatory.

Desktop:

1280+

optimized arena layout

Tablet:

768–1279

Mobile:

320–767

Test at:

320px

375px

390px

414px

768px

1024px

1280px

1440px

No horizontal scrolling.

Questions must remain readable.

Answer buttons must be touch friendly.

Duel UI should work especially well on mobile.

==================================================

ACCESSIBILITY

==================================================

Use:

- semantic HTML

- keyboard navigation

- visible focus states

- aria labels where necessary

- sufficient contrast

- reduced-motion support

If prefers-reduced-motion is enabled:

reduce nonessential animations.

==================================================

ERROR STATES

==================================================

Every API/WebSocket operation must have:

loading

success

error

empty

offline/reconnecting

Examples:

"Unable to connect to QuizIt"

"Matchmaking connection lost. Reconnecting..."

"Quiz could not be loaded."

"Your session has expired."

Use Sonner/toasts for lightweight feedback.

Use inline error UI for important gameplay errors.

==================================================

WEBSOCKET RECONNECTION

==================================================

Implement a reusable WebSocket manager.

Features:

connect

disconnect

reconnect

heartbeat where appropriate

connection state

cleanup

exponential backoff

Never create uncontrolled WebSocket connections.

Clean them up on route changes/unmount.

==================================================

DATA ARCHITECTURE

==================================================

Create services:

authService

quizService

mcqService

topicService

matchmakingService

duelService

Create types for all API responses.

Do not put fetch calls directly inside UI components.

==================================================

SECURITY

==================================================

Never:

- store password

- store JWT in localStorage

- put JWT in URL

- expose access token

- trust frontend score

- display correct answer during active question

- invent authentication state

Use credentials: include for API/WebSocket authentication.

==================================================

IMPORTANT CURRENT BACKEND LIMITATIONS

==================================================

Do not hide these limitations.

Current backend has:

1. No GET topics endpoint.

2. No leaderboard endpoint.

3. No profile endpoint.

4. No logout endpoint.

5. Matchmaking currently hardcodes DSA and 2 questions.

6. Current duel endpoint is /duelroom/join-room-test.

7. Current backend sends correctOption during active gameplay.

8. Current quiz backend primarily supports random question selection.

9. AI/custom quiz modes are schema-level concepts but not complete features.

Build the frontend so these can be added later without rewriting the UI.

Use service interfaces/adapters.

==================================================

DEMO / FALLBACK DATA

==================================================

For features that have no backend endpoint yet:

- leaderboard

- weekly stats

- friend list

- achievements

- streak history

- daily challenge metadata

Use demo data ONLY through dedicated mock services.

Example:

services/mockLeaderboardService.ts

Never put mock data directly into page components.

Clearly label demo-only features where appropriate.

==================================================

SHADCN/UI

==================================================

Use shadcn/ui components where useful:

Button

Card

Badge

Dialog

Sheet

DropdownMenu

Avatar

Progress

Tabs

Tooltip

Separator

Skeleton

Toast

Input

Select

Customize them heavily to match QuizIt's dark green design.

Do not make the app look like default shadcn.

==================================================

ICONS

==================================================

Use Lucide icons.

Do not use random emoji as the primary UI icon system.

Emoji can appear sparingly in achievements/rewards.

==================================================

LOGO

==================================================

Create a simple original QuizIt wordmark.

Concept:

QUIZIT

Minimal geometric Q / puzzle-inspired mark.

Do not copy another company's logo.

Use green accent.

==================================================

PERFORMANCE

==================================================

Avoid unnecessary client rendering.

Lazy-load noncritical pages/components.

Avoid huge images.

Use optimized assets.

Do not add unnecessary dependencies.

==================================================

CODE QUALITY

==================================================

Use strict TypeScript.

Avoid:

any

unused imports

duplicated components

hardcoded API URLs

hardcoded user data in production components

Use reusable types.

Add comments only where they explain important integration behavior.

==================================================

FINAL ROUTES

==================================================

Create:

/login

/signup

/arena

/practice

/practice/:topic

/practice/:topic/result

/duels

/matchmaking

/duel/:id

/duel/:id/result

/challenges

/leaderboard

/progress

/profile

/settings

==================================================

DELIVERABLE

==================================================

Build the complete frontend.

Prioritize these first:

1. Login

2. Signup

3. Arena

4. Practice

5. Practice Quiz

6. Matchmaking

7. Duel Room

8. Duel Result

9. Profile

10. Responsive navigation

Then build:

11. Leaderboard

12. Progress

13. Challenges

14. Settings

The application must feel like a polished real product.

Do not create a generic SaaS dashboard.

The emotional feeling should be:

"One more game."

The user should immediately want to press:

QUICK DUEL

The design should feel:

minimal

dark

competitive

smart

premium

fast

focused

Use subtle modern animations and shadcn-style components without making the UI visually noisy.

==================================================

MOST IMPORTANT RULE

==================================================

DO NOT CHANGE THE BACKEND.

Build an integration layer around the existing FastAPI backend.

If a desired frontend feature has no backend API:

1. create the UI

2. create an isolated service interface

3. use demo/mock data only where necessary

4. clearly mark the integration TODO

5. do not invent or call nonexistent endpoints

Before finishing, verify that:

- login calls the real backend

- signup calls the real backend

- credentials are included

- quiz creation uses the real backend

- MCQs use the real backend

- matchmaking uses the real WebSocket

- duel room uses the real WebSocket

- no old /ws/duelroom/{roomId} endpoint is referenced

- no JWT is stored in localStorage

- no correct answer is shown during an active question

- mobile layout works at 320px width

- desktop layout works at 1440px width

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://quizlt.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7a194fa5-7a2e-40fd-8c48-47b6b713d125).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
